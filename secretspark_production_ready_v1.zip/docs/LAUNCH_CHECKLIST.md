# SecretSpark launch checklist

## Ready in this package
- Main mobile-first SecretSpark creation flow
- Cinematic preview flow
- Delivery simulation/payment simulation flow
- Supabase insert/read/open tracking foundation
- `/r/<secretCode>` receiver route
- `/terms`, `/privacy`, `/contact`
- Vercel SPA rewrites
- SEO title/description/OpenGraph basics
- Supabase MVP security hardening SQL

## Still required before real public paid launch
- Real Stripe Checkout integration
- Real delivery APIs: Email/SMS/Telegram/WhatsApp
- CAPTCHA or server-side rate limiting before sending
- Admin panel for reports and abuse review
- Final legal review for Terms and Privacy
- Branded support email such as support@secretspark.me
