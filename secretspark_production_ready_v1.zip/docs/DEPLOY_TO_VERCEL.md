# SecretSpark deploy to Vercel

1. Upload all project files to the GitHub repository `secretspark`.
2. In Vercel, connect the repository.
3. Vercel will use `vercel.json` automatically.
4. Build output is `build/web`.
5. Custom domain: `secretspark.me`.
6. DNS records in Namecheap:
   - A Record: `@` -> `216.198.79.1`
   - CNAME Record: `www` -> `cname.vercel-dns.com`

If deployment fails because Flutter is missing, verify these files exist:
- `vercel_install.sh`
- `vercel_build.sh`
- `vercel.json`
