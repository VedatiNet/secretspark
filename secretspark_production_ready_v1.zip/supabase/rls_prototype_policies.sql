-- SecretSpark prototype RLS policies. Run only if insert is blocked by RLS.
alter table public.sparks enable row level security;
alter table public.spark_events enable row level security;

drop policy if exists "public_can_create_demo_sparks" on public.sparks;
create policy "public_can_create_demo_sparks"
on public.sparks
for insert
to anon
with check (is_demo = true or payment_status in ('pending', 'paid'));

drop policy if exists "public_can_read_non_expired_sparks" on public.sparks;
create policy "public_can_read_non_expired_sparks"
on public.sparks
for select
to anon
using (expires_at > now());

drop policy if exists "public_can_mark_spark_opened" on public.sparks;
create policy "public_can_mark_spark_opened"
on public.sparks
for update
to anon
using (expires_at > now())
with check (expires_at > now());

drop policy if exists "public_can_insert_spark_events" on public.spark_events;
create policy "public_can_insert_spark_events"
on public.spark_events
for insert
to anon
with check (true);
