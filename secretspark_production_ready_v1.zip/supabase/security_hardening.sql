-- SecretSpark security hardening for MVP.
-- Run this AFTER the initial schema is created.
-- It keeps public insert/open working while avoiding broad table access.

revoke all on public.sparks from anon;
revoke all on public.spark_events from anon;

grant usage on schema public to anon;
grant select, insert, update on public.sparks to anon;
grant insert on public.spark_events to anon;

alter table public.sparks enable row level security;
alter table public.spark_events enable row level security;

drop policy if exists public_create_sparks on public.sparks;
create policy public_create_sparks
on public.sparks
for insert
to anon
with check (
  char_length(message_text) between 1 and 2200
  and category in ('PARTNER', 'FAMILY', 'FRIEND', 'WORK')
  and payment_status in ('pending', 'paid', 'demo')
  and expires_at > now()
);

drop policy if exists public_read_valid_sparks_by_code on public.sparks;
create policy public_read_valid_sparks_by_code
on public.sparks
for select
to anon
using (
  expires_at > now()
);

drop policy if exists public_mark_opened on public.sparks;
create policy public_mark_opened
on public.sparks
for update
to anon
using (expires_at > now())
with check (expires_at > now());

drop policy if exists public_insert_spark_events on public.spark_events;
create policy public_insert_spark_events
on public.spark_events
for insert
to anon
with check (
  event_type in ('created', 'opened', 'delivery_previewed', 'payment_simulated', 'reported')
);

create index if not exists idx_sparks_secret_code_not_expired
on public.sparks(secret_code, expires_at);

create index if not exists idx_spark_events_spark_id_created_at
on public.spark_events(spark_id, created_at desc);
