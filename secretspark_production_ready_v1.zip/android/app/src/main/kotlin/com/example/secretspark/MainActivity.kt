package com.example.secretspark

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
