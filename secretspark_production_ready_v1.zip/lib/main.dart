import 'package:flutter/material.dart';

import 'backend/backend_runtime.dart';
import 'receiver_spark_loader_page.dart';
import 'legal_page.dart';
import 'secret_spark_sender_page.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SecretSparkBackendRuntime.initializeIfConfigured();
  runApp(const SecretSparkApp());
}

class SecretSparkApp extends StatelessWidget {
  const SecretSparkApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'SecretSpark',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF030305),
        useMaterial3: true,
      ),
      onGenerateRoute: (settings) {
        final uri = Uri.parse(settings.name ?? '/');
        final parts = uri.pathSegments;
        if (uri.path == '/terms') {
          return MaterialPageRoute(
            builder: (_) => const LegalPage(kind: LegalPageKind.terms),
            settings: settings,
          );
        }
        if (uri.path == '/privacy') {
          return MaterialPageRoute(
            builder: (_) => const LegalPage(kind: LegalPageKind.privacy),
            settings: settings,
          );
        }
        if (uri.path == '/contact') {
          return MaterialPageRoute(
            builder: (_) => const LegalPage(kind: LegalPageKind.contact),
            settings: settings,
          );
        }
        if (parts.length == 2 && parts.first == 'r') {
          return MaterialPageRoute(
            builder: (_) => ReceiverSparkLoaderPage(secretCode: parts.last),
            settings: settings,
          );
        }
        return MaterialPageRoute(
          builder: (_) => const SecretSparkSenderPage(),
          settings: settings,
        );
      },
    );
  }
}
