/// SecretSpark Supabase config.
///
/// Replace these values after creating the Supabase project.
/// Use the anon public key here only. Never place service_role keys in Flutter.
class SecretSparkSupabaseConfig {
  static const String url = 'https://kcykhllevdmupldrzroz.supabase.co';
  static const String anonKey = 'sb_publishable_wQKqhSiImVFjGlIwQIzvUQ_BzZFZh4j';

  static bool get isConfigured =>
      url.startsWith('https://') &&
      !url.contains('YOUR_PROJECT_REF') &&
      anonKey.isNotEmpty &&
      !anonKey.contains('YOUR_SUPABASE_ANON_KEY');
}
