import 'package:supabase_flutter/supabase_flutter.dart';

import 'secret_code.dart';
import 'spark_draft.dart';
import 'supabase_config.dart';

class SparkBackendService {
  SparkBackendService({SupabaseClient? client})
      : _client = client ?? Supabase.instance.client;

  final SupabaseClient _client;

  static Future<void> initialize() async {
    if (!SecretSparkSupabaseConfig.isConfigured) {
      throw StateError(
        'Supabase is not configured. Update lib/backend/supabase_config.dart first.',
      );
    }

    await Supabase.initialize(
      url: SecretSparkSupabaseConfig.url,
      anonKey: SecretSparkSupabaseConfig.anonKey,
    );
  }

  Future<SparkRecord> createDemoSpark(SparkDraft draft) async {
    final secretCode = SecretCodeGenerator.create();

    final inserted = await _client
        .from('sparks')
        .insert(draft.toInsertJson(secretCode: secretCode))
        .select()
        .single();

    await _client.from('spark_events').insert({
      'spark_id': inserted['id'],
      'event_type': 'created',
      'metadata': {
        'source': 'flutter_demo',
        'delivery_method': draft.deliveryMethod.dbValue,
      },
    });

    return SparkRecord.fromJson(inserted);
  }

  Future<SparkRecord?> getSparkByCode(String secretCode) async {
    final rows = await _client
        .from('sparks')
        .select()
        .eq('secret_code', secretCode)
        .limit(1);

    if (rows is! List || rows.isEmpty) return null;
    return SparkRecord.fromJson(rows.first as Map<String, dynamic>);
  }

  Future<void> markOpened({required String sparkId}) async {
    await _client
        .from('sparks')
        .update({'opened_at': DateTime.now().toUtc().toIso8601String()})
        .eq('id', sparkId);

    await _client.from('spark_events').insert({
      'spark_id': sparkId,
      'event_type': 'opened',
      'metadata': {'source': 'receiver_page'},
    });
  }
}
