enum SparkCategory { partner, family, friend, work }
enum SparkDeliveryMethod { whatsapp, sms, email, telegram }
enum SparkNameDisplayMode { addAtEnd, alreadyInMessage, noName }

extension SparkCategoryDb on SparkCategory {
  String get dbValue {
    switch (this) {
      case SparkCategory.partner:
        return 'PARTNER';
      case SparkCategory.family:
        return 'FAMILY';
      case SparkCategory.friend:
        return 'FRIEND';
      case SparkCategory.work:
        return 'WORK';
    }
  }
}

extension SparkDeliveryDb on SparkDeliveryMethod {
  String get dbValue {
    switch (this) {
      case SparkDeliveryMethod.whatsapp:
        return 'whatsapp';
      case SparkDeliveryMethod.sms:
        return 'sms';
      case SparkDeliveryMethod.email:
        return 'email';
      case SparkDeliveryMethod.telegram:
        return 'telegram';
    }
  }
}

extension SparkNameDisplayDb on SparkNameDisplayMode {
  String get dbValue {
    switch (this) {
      case SparkNameDisplayMode.addAtEnd:
        return 'add_at_end';
      case SparkNameDisplayMode.alreadyInMessage:
        return 'already_in_message';
      case SparkNameDisplayMode.noName:
        return 'no_name';
    }
  }
}

class SparkDraft {
  const SparkDraft({
    required this.category,
    required this.messageText,
    required this.senderName,
    required this.nameDisplayMode,
    required this.deliveryMethod,
    required this.recipientMasked,
    required this.recipientHash,
    this.priceCents = 199,
    this.currency = 'USD',
    this.isDemo = true,
  });

  final SparkCategory category;
  final String messageText;
  final String? senderName;
  final SparkNameDisplayMode nameDisplayMode;
  final SparkDeliveryMethod deliveryMethod;
  final String recipientMasked;
  final String recipientHash;
  final int priceCents;
  final String currency;
  final bool isDemo;

  Map<String, dynamic> toInsertJson({required String secretCode}) {
    return {
      'secret_code': secretCode,
      'category': category.dbValue,
      'message_text': messageText,
      'sender_name': senderName,
      'name_display_mode': nameDisplayMode.dbValue,
      'delivery_method': deliveryMethod.dbValue,
      'recipient_masked': recipientMasked,
      'recipient_hash': recipientHash,
      'price_cents': priceCents,
      'currency': currency,
      'payment_status': isDemo ? 'demo' : 'pending',
      'delivery_status': isDemo ? 'demo' : 'pending',
      'is_demo': isDemo,
    };
  }
}

class SparkRecord {
  const SparkRecord({
    required this.id,
    required this.secretCode,
    required this.category,
    required this.messageText,
    required this.senderName,
    required this.nameDisplayMode,
    required this.createdAt,
    required this.expiresAt,
  });

  final String id;
  final String secretCode;
  final String category;
  final String messageText;
  final String? senderName;
  final String nameDisplayMode;
  final DateTime createdAt;
  final DateTime expiresAt;

  factory SparkRecord.fromJson(Map<String, dynamic> json) {
    return SparkRecord(
      id: json['id'] as String,
      secretCode: json['secret_code'] as String,
      category: json['category'] as String,
      messageText: json['message_text'] as String,
      senderName: json['sender_name'] as String?,
      nameDisplayMode: json['name_display_mode'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      expiresAt: DateTime.parse(json['expires_at'] as String),
    );
  }
}
