import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'supabase_config.dart';

/// Initializes Supabase only when real project keys are configured.
/// This keeps the prototype runnable in demo mode without crashing.
class SecretSparkBackendRuntime {
  SecretSparkBackendRuntime._();

  static bool _attempted = false;
  static bool _ready = false;

  static bool get isConfigured => SecretSparkSupabaseConfig.isConfigured;
  static bool get isReady => _ready;

  static Future<bool> initializeIfConfigured() async {
    if (_attempted) return _ready;
    _attempted = true;

    if (!SecretSparkSupabaseConfig.isConfigured) {
      _ready = false;
      return false;
    }

    try {
      await Supabase.initialize(
        url: SecretSparkSupabaseConfig.url,
        anonKey: SecretSparkSupabaseConfig.anonKey,
      );
      _ready = true;
      return true;
    } catch (error, stackTrace) {
      debugPrint('SecretSpark Supabase init failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      _ready = false;
      return false;
    }
  }
}
