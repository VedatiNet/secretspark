import 'dart:math';
import 'package:flutter/material.dart';

class SecretSparkCinematicPage extends StatefulWidget {
  const SecretSparkCinematicPage({
    super.key,
    this.message = 'Baba dimri i han petat, Edhe i ka shum merak. Her i ha me mish e her i ha me xhiz...',
    this.category = 'PARTNER',
    this.previewMode = false,
    this.senderName = '',
  });

  final String message;
  final String category;
  final bool previewMode;
  final String senderName;

  @override
  State<SecretSparkCinematicPage> createState() => _SecretSparkCinematicPageState();
}

class _SecretSparkCinematicPageState extends State<SecretSparkCinematicPage> with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _orbitController; 
  late AnimationController _suspenseController; 
  late AnimationController _twinkleController; 
  
  late Animation<double> _eclipseScale;
  late Animation<double> _eclipseShake;
  late Animation<double> _nebulaExpansion; 
  late Animation<double> _shockwaveOpacity;
  late Animation<double> _flashIntensity; 
  late Animation<double> _bottomTextFade; 
  late Animation<double> _letterScale;
  late Animation<double> _letterFade;
  late Animation<double> _letterRotation;
  late Animation<double> _ctaFade; 

  List<OrbitalParticle> _ambientParticles = [];
  List<PremiumGoldSpark> _goldSparks = [];
  List<Star> _starfield = [];
  bool _isTriggered = false;
  final Random _random = Random();

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..repeat(reverse: true);

    _orbitController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 4),
    )..repeat();

    _twinkleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    )..repeat(reverse: true);

    _suspenseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 7500),
    );

    _starfield = List.generate(90, (index) {
      return Star(x: _random.nextDouble(), y: _random.nextDouble(), size: _random.nextDouble() * 1.3 + 0.4, twinkleSpeed: _random.nextDouble() * 0.4 + 0.4);
    });

    _ambientParticles = List.generate(35, (index) {
      return OrbitalParticle(radius: _random.nextDouble() * 40 + 90, angle: _random.nextDouble() * pi * 2, speed: _random.nextDouble() * 0.02 + 0.01, size: _random.nextDouble() * 1.8 + 0.8, color: const Color(0xFFFFD700).withOpacity(0.6));
    });

    _eclipseScale = TweenSequence([
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 0.35).chain(CurveTween(curve: Curves.easeOutCubic)), weight: 45),
      TweenSequenceItem(tween: ConstantTween<double>(0.35), weight: 10), 
      TweenSequenceItem(tween: Tween<double>(begin: 0.35, end: 0.0), weight: 2), 
      TweenSequenceItem(tween: ConstantTween<double>(0.0), weight: 43),
    ]).animate(_suspenseController);

    _eclipseShake = TweenSequence([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 12.0).chain(CurveTween(curve: Curves.easeInQuad)), weight: 55),
      TweenSequenceItem(tween: ConstantTween<double>(0.0), weight: 45),
    ]).animate(_suspenseController);

    _bottomTextFade = TweenSequence([
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 0.5).chain(CurveTween(curve: Curves.easeIn)), weight: 15),
      TweenSequenceItem(tween: ConstantTween<double>(0.5), weight: 35),
      TweenSequenceItem(tween: Tween<double>(begin: 0.5, end: 0.0).chain(CurveTween(curve: Curves.easeOut)), weight: 5),
      TweenSequenceItem(tween: ConstantTween<double>(0.0), weight: 45),
    ]).animate(_suspenseController);

    _flashIntensity = TweenSequence([
      TweenSequenceItem(tween: ConstantTween<double>(0.0), weight: 54),
      TweenSequenceItem(tween: Tween<double>(begin: 0.0, end: 1.0).chain(CurveTween(curve: Curves.easeOut)), weight: 2),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 0.0).chain(CurveTween(curve: Curves.easeIn)), weight: 8),
      TweenSequenceItem(tween: ConstantTween<double>(0.0), weight: 36),
    ]).animate(_suspenseController);

    _nebulaExpansion = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _suspenseController, curve: const Interval(0.55, 0.85, curve: Curves.easeOutExpo)));
    _shockwaveOpacity = TweenSequence([
      TweenSequenceItem(tween: ConstantTween<double>(0.0), weight: 55),
      TweenSequenceItem(tween: Tween<double>(begin: 1.0, end: 0.0).chain(CurveTween(curve: Curves.easeOutCubic)), weight: 25),
      TweenSequenceItem(tween: ConstantTween<double>(0.0), weight: 20),
    ]).animate(_suspenseController);

    _letterFade = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _suspenseController, curve: const Interval(0.64, 0.90, curve: Curves.easeInQuad)));
    _letterScale = Tween<double>(begin: 0.4, end: 1.0).animate(CurvedAnimation(parent: _suspenseController, curve: const Interval(0.64, 0.95, curve: Curves.linearToEaseOut)));
    _letterRotation = Tween<double>(begin: 0.15, end: 0.0).animate(CurvedAnimation(parent: _suspenseController, curve: const Interval(0.64, 0.93, curve: Curves.easeOutBack)));
    _ctaFade = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _suspenseController, curve: const Interval(0.80, 0.98, curve: Curves.easeIn)));

    _suspenseController.addListener(() {
      setState(() {
        double progress = _suspenseController.value;
        for (var p in _ambientParticles) {
          p.update(_isTriggered && progress < 0.55);
        }
        if (progress >= 0.55) {
          for (var spark in _goldSparks) {
            spark.update();
          }
        }
      });
    });

    _orbitController.addListener(() {
      if (!_isTriggered) {
        setState(() {
          for (var p in _ambientParticles) {
            p.orbit();
          }
        });
      }
    });

    Future.delayed(const Duration(milliseconds: 600), () {
      if (mounted) _startAutomaticCinematic();
    });
  }

  void _startAutomaticCinematic() {
    if (_isTriggered) return;
    setState(() { _isTriggered = true; });
    _pulseController.stop();
    _suspenseController.forward();

    _goldSparks = List.generate(70, (index) {
      return PremiumGoldSpark(angle: _random.nextDouble() * pi * 2, speed: _random.nextDouble() * 8 + 3, length: _random.nextDouble() * 15 + 5, width: _random.nextDouble() * 1.5 + 0.5, opacityDecay: _random.nextDouble() * 0.012 + 0.008);
    });
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _orbitController.dispose();
    _twinkleController.dispose();
    _suspenseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final centerOffset = Offset(screenSize.width / 2, screenSize.height / 2);
    double shakeOffset = 0.0;
    if (_isTriggered && _suspenseController.value < 0.55) {
      shakeOffset = (sin(_suspenseController.value * 280) * _eclipseShake.value);
    }

    return Scaffold(
      backgroundColor: const Color(0xFF030305), 
      body: Stack(
        children: [
          Positioned.fill(child: AnimatedBuilder(animation: _twinkleController, builder: (context, child) => CustomPaint(painter: LiveStarfieldPainter(stars: _starfield, twinkleValue: _twinkleController.value, center: centerOffset)))),
          if (_suspenseController.value < 0.55) Positioned.fill(child: CustomPaint(painter: AmbientParticlePainter(particles: _ambientParticles, center: centerOffset))),
          if (_isTriggered && _suspenseController.value >= 0.55) ...[
            Positioned.fill(child: CustomPaint(painter: PremiumCinematicExplosionPainter(progress: _nebulaExpansion.value, opacity: _shockwaveOpacity.value, center: centerOffset))),
            Positioned.fill(child: CustomPaint(painter: GoldSparkPainter(sparks: _goldSparks, center: centerOffset))),
          ],
          if (_flashIntensity.value > 0) Positioned.fill(child: Container(color: Colors.white.withOpacity(_flashIntensity.value * 0.85))),
          if (_suspenseController.value < 0.55)
            Center(
              child: Transform.translate(
                offset: Offset(shakeOffset, _random.nextBool() ? shakeOffset : -shakeOffset),
                child: Transform.scale(
                  scale: _eclipseScale.value,
                  child: Container(
                    width: 150,
                    height: 150,
                    decoration: BoxDecoration(shape: BoxShape.circle, color: const Color(0xFF060608), boxShadow: [BoxShadow(color: _isTriggered ? const Color(0xFFFFD700).withOpacity(0.5 + (_suspenseController.value * 0.3)) : const Color(0xFFFFD700).withOpacity(0.2), blurRadius: _isTriggered ? 35 + (_eclipseShake.value * 2) : 20 + (_pulseController.value * 10), spreadRadius: _isTriggered ? 2 : 1)]),
                  ),
                ),
              ),
            ),
          if (_suspenseController.value < 0.55)
            Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.only(bottom: 50.0), 
                child: Opacity(opacity: _bottomTextFade.value, child: const Text("LOADING SECRET SPARK", style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w400, letterSpacing: 5))),
              ),
            ),
          Center(
            child: AnimatedBuilder(
              animation: _suspenseController,
              builder: (context, child) {
                return Opacity(
                  opacity: _letterFade.value,
                  child: Transform(
                    transform: Matrix4.identity()..setEntry(3, 2, 0.0006)..scale(_letterScale.value)..rotateY(_letterRotation.value)..rotateZ(_letterRotation.value * 0.1),
                    alignment: Alignment.center,
                    child: _letterFade.value > 0.0 
                        ? Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SecretSparkLetterWidget(message: widget.message, category: widget.category, senderName: widget.senderName),
                              const SizedBox(height: 30), 
                              Opacity(
                                opacity: _ctaFade.value,
                                child: widget.previewMode
                                    ? const _PreviewApprovalBar()
                                    : GestureDetector(
                                        onTap: () {},
                                        child: const MouseRegion(
                                          cursor: SystemMouseCursors.click,
                                          child: Padding(
                                            padding: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Text("Want to send a SecretSpark too? ", style: TextStyle(color: Colors.white30, fontSize: 11, fontWeight: FontWeight.w400)),
                                                Text("Click here", style: TextStyle(color: Color(0xFFFFD700), fontSize: 11, fontWeight: FontWeight.w600, decoration: TextDecoration.underline)),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                              ),
                            ],
                          )
                        : const SizedBox.shrink(),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class Star {
  final double x; final double y; final double size; final double twinkleSpeed;
  Star({required this.x, required this.y, required this.size, required this.twinkleSpeed});
}

class LiveStarfieldPainter extends CustomPainter {
  final List<Star> stars; final double twinkleValue; final Offset center;
  LiveStarfieldPainter({required this.stars, required this.twinkleValue, required this.center});
  @override
  void paint(Canvas canvas, Size size) {
    final nebulaPaint = Paint()..shader = RadialGradient(colors: [const Color(0xFF141008).withOpacity(0.25), Colors.transparent]).createShader(Rect.fromCircle(center: center, radius: size.width * 0.4));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), nebulaPaint);
    for (var star in stars) {
      double alpha = 0.2 + (sin(twinkleValue * pi * 2 * star.twinkleSpeed) * 0.5 + 0.5) * 0.6;
      canvas.drawCircle(Offset(star.x * size.width, star.y * size.height), star.size, Paint()..color = Colors.white.withOpacity(alpha.clamp(0.0, 1.0)));
    }
  }
  @override bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class PremiumCinematicExplosionPainter extends CustomPainter {
  final double progress; final double opacity; final Offset center;
  PremiumCinematicExplosionPainter({required this.progress, required this.opacity, required this.center});
  @override
  void paint(Canvas canvas, Size size) {
    if (opacity <= 0) return;
    double radius = size.width * 0.9 * progress;
    final cloudPaint = Paint()..shader = RadialGradient(colors: [Colors.white.withOpacity(opacity * 0.9), const Color(0xFFFFD700).withOpacity(opacity * 0.55), const Color(0xFFB78429).withOpacity(opacity * 0.2), Colors.transparent], stops: const [0.0, 0.3, 0.7, 1.0]).createShader(Rect.fromCircle(center: center, radius: radius));
    canvas.drawCircle(center, radius, cloudPaint);
  }
  @override bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class PremiumGoldSpark {
  double currentRadius = 0; final double angle; final double speed; final double length; final double width; final double opacityDecay; double opacity = 1.0;
  PremiumGoldSpark({required this.angle, required this.speed, required this.length, required this.width, required this.opacityDecay});
  void update() { currentRadius += speed; opacity -= opacityDecay; if (opacity < 0) opacity = 0; }
}

class GoldSparkPainter extends CustomPainter {
  final List<PremiumGoldSpark> sparks; final Offset center;
  GoldSparkPainter({required this.sparks, required this.center});
  @override
  void paint(Canvas canvas, Size size) {
    for (var s in sparks) {
      if (s.opacity <= 0) continue;
      double startX = center.dx + cos(s.angle) * s.currentRadius;
      double startY = center.dy + sin(s.angle) * s.currentRadius;
      double endX = center.dx + cos(s.angle) * (s.currentRadius + s.length);
      double endY = center.dy + sin(s.angle) * (s.currentRadius + s.length);
      canvas.drawLine(Offset(startX, startY), Offset(endX, endY), Paint()..color = const Color(0xFFFFE082).withOpacity(s.opacity)..strokeWidth = s.width..strokeCap = StrokeCap.round..style = PaintingStyle.stroke);
    }
  }
  @override bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class OrbitalParticle {
  double radius; double angle; final double speed; final double size; final Color color;
  OrbitalParticle({required this.radius, required this.angle, required this.speed, required this.size, required this.color});
  void orbit() { angle += speed; }
  void update(bool isSucking) {
    if (isSucking) { radius -= 2.2; if (radius < 0) radius = 0; angle += 0.12; } else { angle += speed; }
  }
}

class AmbientParticlePainter extends CustomPainter {
  final List<OrbitalParticle> particles; final Offset center;
  AmbientParticlePainter({required this.particles, required this.center});
  @override
  void paint(Canvas canvas, Size size) {
    for (var p in particles) {
      if (p.radius <= 0) continue;
      double px = center.dx + cos(p.angle) * p.radius;
      double py = center.dy + sin(p.angle) * p.radius;
      canvas.drawCircle(Offset(px, py), p.size, Paint()..color = p.color);
    }
  }
  @override bool shouldRepaint(CustomPainter oldDelegate) => true;
}

class SecretSparkLetterWidget extends StatelessWidget {
  const SecretSparkLetterWidget({super.key, required this.message, required this.category, this.senderName = ''});

  final String message;
  final String category;
  final String senderName;

  String get _categoryLabel {
    switch (category) {
      case 'FAMILY':
        return 'Family Moment';
      case 'FRIEND':
        return 'Friendship Moment';
      case 'WORK':
        return 'Appreciation Moment';
      case 'PARTNER':
      default:
        return 'Heart Moment';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 320,
      constraints: const BoxConstraints(minHeight: 360, maxHeight: 430),
      padding: const EdgeInsets.all(28),
      decoration: BoxDecoration(
        color: const Color(0xFF0B0B0E),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.2), width: 1.0),
        boxShadow: [
          BoxShadow(color: const Color(0xFFFFD700).withOpacity(0.04), blurRadius: 40, spreadRadius: 1),
          BoxShadow(color: Colors.black.withOpacity(0.9), blurRadius: 30),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.auto_awesome, color: Color(0xFFFFD700), size: 28),
          const SizedBox(height: 24),
          Flexible(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Text(
                '“ $message ”',
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Color(0xFFECEFF1),
                  fontSize: 17,
                  fontStyle: FontStyle.italic,
                  height: 1.6,
                  fontFamily: 'Georgia',
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text('— $_categoryLabel', style: const TextStyle(color: Colors.white24, fontSize: 10, letterSpacing: 4)),
          if (senderName.trim().isNotEmpty) ...[
            const SizedBox(height: 18),
            Container(
              width: 54,
              height: 1,
              color: const Color(0xFFFFD700).withOpacity(0.20),
            ),
            const SizedBox(height: 16),
            Text(
              'From ${senderName.trim()} ✨',
              textAlign: TextAlign.center,
              style: TextStyle(
                color: const Color(0xFFECEFF1).withOpacity(0.72),
                fontSize: 14,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.4,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _PreviewApprovalBar extends StatelessWidget {
  const _PreviewApprovalBar();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 360),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Does this reveal feel perfect?',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white.withOpacity(0.70), fontSize: 11, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(false),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: Colors.white70,
                        side: BorderSide(color: Colors.white.withOpacity(0.18)),
                        minimumSize: const Size(0, 38),
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                        textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: const Text('Edit'),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(context).pop(true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFFFD700),
                        foregroundColor: const Color(0xFF050505),
                        elevation: 0,
                        minimumSize: const Size(0, 38),
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 0),
                        textStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.w900),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: const Text('Approve'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
