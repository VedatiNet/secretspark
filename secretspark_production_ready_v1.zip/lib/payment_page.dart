import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'prepare_moment_page.dart';

class PaymentPage extends StatefulWidget {
  const PaymentPage({
    super.key,
    required this.message,
    required this.category,
    required this.senderName,
    required this.channelTitle,
    required this.safeRecipient,
    required this.demoLink,
  });

  final String message;
  final String category;
  final String senderName;
  final String channelTitle;
  final String safeRecipient;
  final String demoLink;

  @override
  State<PaymentPage> createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;
  bool _processing = false;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1400))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  Future<void> _simulatePayment() async {
    if (_processing) return;
    HapticFeedback.lightImpact();
    setState(() => _processing = true);
    await Future.delayed(const Duration(milliseconds: 950));
    if (!mounted) return;
    setState(() => _processing = false);
    await Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => PrepareMomentPage(
          message: widget.message,
          category: widget.category,
          senderName: widget.senderName,
          channelTitle: widget.channelTitle,
          safeRecipient: widget.safeRecipient,
          demoLink: widget.demoLink,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050816),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(child: CustomPaint(painter: _PaymentBackgroundPainter())),
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 28),
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      IconButton(
                        onPressed: () => Navigator.of(context).pop(),
                        icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70),
                      ),
                      const Spacer(),
                      Text('SecretSpark', style: TextStyle(color: Colors.white.withOpacity(0.78), fontWeight: FontWeight.w900)),
                      const Spacer(),
                      const SizedBox(width: 48),
                    ],
                  ),
                  const SizedBox(height: 18),
                  FadeTransition(
                    opacity: Tween<double>(begin: 0.72, end: 1).animate(CurvedAnimation(parent: _pulse, curve: Curves.easeInOut)),
                    child: Container(
                      width: 92,
                      height: 92,
                      margin: const EdgeInsets.symmetric(horizontal: 116),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        gradient: RadialGradient(colors: [const Color(0xFFFFD700).withOpacity(0.75), const Color(0xFFFF7AE6).withOpacity(0.20), Colors.transparent]),
                        boxShadow: [BoxShadow(color: const Color(0xFFFFD700).withOpacity(0.22), blurRadius: 44, spreadRadius: 8)],
                      ),
                      child: const Icon(Icons.lock_rounded, color: Colors.white, size: 34),
                    ),
                  ),
                  const SizedBox(height: 22),
                  const Text(
                    'Deliver this moment ✨',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white, fontSize: 29, fontWeight: FontWeight.w900, height: 1.04),
                  ),
                  const SizedBox(height: 9),
                  Text(
                    'A private cinematic reveal, prepared for one receiver.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white.withOpacity(0.52), fontSize: 13.5, height: 1.42, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 24),
                  _PriceCard(),
                  const SizedBox(height: 16),
                  _SummaryCard(channelTitle: widget.channelTitle, safeRecipient: widget.safeRecipient),
                  const SizedBox(height: 16),
                  _IncludedCard(),
                  const SizedBox(height: 22),
                  ElevatedButton.icon(
                    onPressed: _processing ? null : _simulatePayment,
                    icon: _processing
                        ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2.4, color: Color(0xFF050816)))
                        : const Icon(Icons.credit_card_rounded),
                    label: Text(_processing ? 'Processing demo payment...' : 'Simulate Payment'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFFFFD700),
                      disabledBackgroundColor: const Color(0xFFFFD700).withOpacity(0.70),
                      foregroundColor: const Color(0xFF050816),
                      elevation: 0,
                      minimumSize: const Size(double.infinity, 58),
                      textStyle: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.2),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Demo mode: no real payment is charged. Stripe/Apple Pay/Google Pay will be connected later.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white.withOpacity(0.35), fontSize: 11.5, height: 1.4, fontWeight: FontWeight.w600),
                  ),
                ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PriceCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.075),
        borderRadius: BorderRadius.circular(32),
        border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.22)),
        boxShadow: [BoxShadow(color: const Color(0xFFFFD700).withOpacity(0.10), blurRadius: 44, offset: const Offset(0, 18))],
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
            decoration: BoxDecoration(
              color: const Color(0xFFFFD700).withOpacity(0.12),
              borderRadius: BorderRadius.circular(99),
              border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.25)),
            ),
            child: const Text('ONE MOMENT', style: TextStyle(color: Color(0xFFFFD700), fontSize: 11, fontWeight: FontWeight.w900, letterSpacing: 1.2)),
          ),
          const SizedBox(height: 18),
          const Text('\$1.99', style: TextStyle(color: Colors.white, fontSize: 46, fontWeight: FontWeight.w900, height: 0.95)),
          const SizedBox(height: 8),
          Text('for one cinematic SecretSpark delivery', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(0.50), fontSize: 13, fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}

class _SummaryCard extends StatelessWidget {
  const _SummaryCard({required this.channelTitle, required this.safeRecipient});

  final String channelTitle;
  final String safeRecipient;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0B1020).withOpacity(0.76),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.10)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Delivery summary', style: TextStyle(color: Colors.white.withOpacity(0.92), fontSize: 15, fontWeight: FontWeight.w900)),
          const SizedBox(height: 14),
          _SummaryRow(icon: Icons.near_me_rounded, label: 'Channel', value: channelTitle),
          const SizedBox(height: 10),
          _SummaryRow(icon: Icons.person_rounded, label: 'Receiver', value: safeRecipient),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  const _SummaryRow({required this.icon, required this.label, required this.value});
  final IconData icon;
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, color: const Color(0xFFFFD700), size: 19),
        const SizedBox(width: 10),
        SizedBox(width: 72, child: Text(label, style: TextStyle(color: Colors.white.withOpacity(0.42), fontSize: 12, fontWeight: FontWeight.w800))),
        Expanded(child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w800))),
      ],
    );
  }
}

class _IncludedCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final items = [
      ('Cinematic receiver reveal', Icons.auto_awesome_rounded),
      ('Private SecretSpark link', Icons.link_rounded),
      ('Selected delivery channel', Icons.send_rounded),
      ('No login, no app download', Icons.verified_user_rounded),
    ];

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.055),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: Colors.white.withOpacity(0.09)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('What is included', style: TextStyle(color: Colors.white.withOpacity(0.92), fontSize: 15, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          ...items.map((item) => Padding(
                padding: const EdgeInsets.symmetric(vertical: 5),
                child: Row(
                  children: [
                    Icon(item.$2, color: Colors.white.withOpacity(0.72), size: 18),
                    const SizedBox(width: 10),
                    Expanded(child: Text(item.$1, style: TextStyle(color: Colors.white.withOpacity(0.68), fontSize: 12.5, fontWeight: FontWeight.w700))),
                  ],
                ),
              )),
        ],
      ),
    );
  }
}

class _PaymentBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFF050816));
    final gold = Paint()
      ..shader = RadialGradient(colors: [const Color(0xFFFFD700).withOpacity(0.18), Colors.transparent]).createShader(Rect.fromCircle(center: Offset(size.width * 0.70, size.height * 0.18), radius: size.width * 0.76));
    canvas.drawRect(Offset.zero & size, gold);
    final pink = Paint()
      ..shader = RadialGradient(colors: [const Color(0xFFFF7AE6).withOpacity(0.14), Colors.transparent]).createShader(Rect.fromCircle(center: Offset(size.width * 0.10, size.height * 0.74), radius: size.width * 0.80));
    canvas.drawRect(Offset.zero & size, pink);

    final starPaint = Paint()..color = Colors.white.withOpacity(0.22);
    for (int i = 0; i < 38; i++) {
      final x = (i * 89) % size.width;
      final y = (i * 113) % size.height;
      canvas.drawCircle(Offset(x.toDouble(), y.toDouble()), i % 6 == 0 ? 1.25 : 0.65, starPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
