import 'package:flutter/material.dart';

class LegalPage extends StatelessWidget {
  const LegalPage({super.key, required this.kind});

  final LegalPageKind kind;

  @override
  Widget build(BuildContext context) {
    final data = _content(kind);
    return Scaffold(
      backgroundColor: const Color(0xFF050816),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(child: CustomPaint(painter: _LegalBackgroundPainter())),
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 760),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(22, 18, 22, 36),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Row(
                        children: [
                          IconButton(
                            onPressed: () => Navigator.of(context).pushReplacementNamed('/'),
                            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70),
                          ),
                          const Spacer(),
                          const Text(
                            'SecretSpark',
                            style: TextStyle(color: Color(0xFFE5E7EB), fontSize: 18, fontWeight: FontWeight.w900),
                          ),
                          const Spacer(),
                          const SizedBox(width: 48),
                        ],
                      ),
                      const SizedBox(height: 18),
                      Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: const Color(0xFF0B1020).withOpacity(0.84),
                          borderRadius: BorderRadius.circular(30),
                          border: Border.all(color: Colors.white.withOpacity(0.10)),
                          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.28), blurRadius: 44, offset: const Offset(0, 20))],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              data.title,
                              style: const TextStyle(color: Colors.white, fontSize: 30, height: 1.05, fontWeight: FontWeight.w900),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Last updated: May 2026',
                              style: TextStyle(color: Colors.white.withOpacity(0.42), fontSize: 12, fontWeight: FontWeight.w700),
                            ),
                            const SizedBox(height: 22),
                            ...data.sections.map(
                              (section) => Padding(
                                padding: const EdgeInsets.only(bottom: 20),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(section.heading, style: const TextStyle(color: Color(0xFFE5E7EB), fontSize: 17, fontWeight: FontWeight.w900)),
                                    const SizedBox(height: 8),
                                    Text(section.body, style: TextStyle(color: Colors.white.withOpacity(0.66), fontSize: 13.5, height: 1.55, fontWeight: FontWeight.w600)),
                                  ],
                                ),
                              ),
                            ),
                            const SizedBox(height: 12),
                            Wrap(
                              spacing: 10,
                              runSpacing: 10,
                              children: [
                                _LegalChip(label: 'Home', route: '/'),
                                _LegalChip(label: 'Terms', route: '/terms'),
                                _LegalChip(label: 'Privacy', route: '/privacy'),
                                _LegalChip(label: 'Contact', route: '/contact'),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _LegalChip extends StatelessWidget {
  const _LegalChip({required this.label, required this.route});
  final String label;
  final String route;

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      onPressed: () => Navigator.of(context).pushReplacementNamed(route),
      style: OutlinedButton.styleFrom(
        foregroundColor: Colors.white,
        side: BorderSide(color: Colors.white.withOpacity(0.16)),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      child: Text(label),
    );
  }
}

enum LegalPageKind { terms, privacy, contact }

class _LegalContent {
  const _LegalContent({required this.title, required this.sections});
  final String title;
  final List<_LegalSection> sections;
}

class _LegalSection {
  const _LegalSection(this.heading, this.body);
  final String heading;
  final String body;
}

_LegalContent _content(LegalPageKind kind) {
  switch (kind) {
    case LegalPageKind.terms:
      return const _LegalContent(
        title: 'Terms of Use',
        sections: [
          _LegalSection('What SecretSpark is', 'SecretSpark lets users create a private cinematic message experience and share a unique reveal link with one receiver. The service is meant for positive, respectful, and lawful personal messages.'),
          _LegalSection('Acceptable use', 'You may not use SecretSpark for harassment, threats, hate, impersonation, scams, illegal activity, spam, or content that violates another person’s rights. We may remove or block content and links that appear abusive or unsafe.'),
          _LegalSection('User content', 'You are responsible for the message content you create and the recipient information you provide. SecretSpark provides the platform and reveal experience, but does not endorse user-generated content.'),
          _LegalSection('Payments and refunds', 'Each paid SecretSpark moment is intended to unlock one delivery/reveal experience. Refund rules will be shown during checkout once live payments are enabled. Demo payments in development do not charge real money.'),
          _LegalSection('Availability', 'We aim to keep SecretSpark available and secure, but we cannot guarantee uninterrupted operation. Links may expire, be rate-limited, or be disabled for abuse prevention.'),
          _LegalSection('Limitation of liability', 'SecretSpark is provided as-is. To the maximum extent allowed by law, we are not responsible for indirect losses, emotional misunderstandings, or misuse of the service by users.'),
        ],
      );
    case LegalPageKind.privacy:
      return const _LegalContent(
        title: 'Privacy Policy',
        sections: [
          _LegalSection('Data we collect', 'We may store the message text, selected category, sender display option, delivery method, receiver contact value, generated secret code, timestamps, payment status, and basic technical events such as created/opened.'),
          _LegalSection('How we use data', 'We use this data to create private reveal links, display the cinematic message, process delivery/payment flows, prevent abuse, improve reliability, and provide support.'),
          _LegalSection('Sensitive content', 'Do not submit highly sensitive information. SecretSpark is designed for emotional notes, not legal, medical, financial, or confidential records.'),
          _LegalSection('Third-party services', 'SecretSpark may use services such as Supabase for database/backend, Vercel for hosting, Stripe for payments, and delivery providers such as email/SMS/Telegram/WhatsApp integrations when enabled.'),
          _LegalSection('Retention and deletion', 'Messages may expire or be deleted after a defined period. Until the deletion system is finalized, contact support for removal requests.'),
          _LegalSection('Security', 'We use HTTPS, private reveal tokens, backend access rules, and abuse-prevention measures. No online system is perfectly secure, but we design SecretSpark to minimize unnecessary data exposure.'),
        ],
      );
    case LegalPageKind.contact:
      return const _LegalContent(
        title: 'Contact',
        sections: [
          _LegalSection('Support', 'For help, abuse reports, deletion requests, or questions, contact: support@secretspark.me'),
          _LegalSection('Abuse reports', 'If you receive a SecretSpark link that feels unsafe, unwanted, abusive, or suspicious, contact us with the reveal link/code so we can review it.'),
          _LegalSection('Business', 'For partnerships, integrations, or platform questions, contact: hello@secretspark.me'),
        ],
      );
  }
}

class _LegalBackgroundPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFF050816));
    final p1 = Paint()
      ..shader = RadialGradient(colors: [const Color(0xFFE879F9).withOpacity(0.18), Colors.transparent]).createShader(
        Rect.fromCircle(center: Offset(size.width * 0.18, size.height * 0.22), radius: size.width * 0.75),
      );
    canvas.drawRect(Offset.zero & size, p1);
    final p2 = Paint()
      ..shader = RadialGradient(colors: [const Color(0xFF60A5FA).withOpacity(0.12), Colors.transparent]).createShader(
        Rect.fromCircle(center: Offset(size.width * 0.84, size.height * 0.78), radius: size.width * 0.82),
      );
    canvas.drawRect(Offset.zero & size, p2);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
