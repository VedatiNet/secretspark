import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'backend/backend_runtime.dart';
import 'backend/spark_backend_service.dart';
import 'backend/spark_draft.dart';
import 'secret_spark_cinematic_page.dart';

class PrepareMomentPage extends StatefulWidget {
  const PrepareMomentPage({
    super.key,
    required this.message,
    required this.category,
    required this.senderName,
    required this.channelTitle,
    required this.safeRecipient,
    required this.recipientRaw,
    required this.deliveryMethod,
    required this.nameDisplayMode,
    required this.demoLink,
  });

  final String message;
  final String category;
  final String senderName;
  final String channelTitle;
  final String safeRecipient;
  final String recipientRaw;
  final String deliveryMethod;
  final String nameDisplayMode;
  final String demoLink;

  @override
  State<PrepareMomentPage> createState() => _PrepareMomentPageState();
}

class _PrepareMomentPageState extends State<PrepareMomentPage> with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _fade;
  int _step = 0;
  bool _done = false;
  String? _createdLink;
  bool _backendCreated = false;

  final List<String> _steps = const [
    'Preparing your SecretSpark moment...',
    'Sealing the envelope...',
    'Creating the delivery link...',
    'Almost ready...',
  ];

  Color get _accent {
    switch (widget.category) {
      case 'FAMILY':
        return const Color(0xFFFBBF24);
      case 'FRIEND':
        return const Color(0xFF60A5FA);
      case 'WORK':
        return const Color(0xFF34D399);
      case 'PARTNER':
      default:
        return const Color(0xFFE879F9);
    }
  }

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat(reverse: true);
    _fade = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _runSequence();
  }

  Future<void> _runSequence() async {
    for (var i = 0; i < _steps.length; i++) {
      if (!mounted) return;
      setState(() => _step = i);

      if (i == 2) {
        await _tryCreateBackendSpark();
      }

      await Future.delayed(const Duration(milliseconds: 850));
    }
    if (!mounted) return;
    HapticFeedback.mediumImpact();
    setState(() => _done = true);
  }

  Future<void> _tryCreateBackendSpark() async {
    if (!SecretSparkBackendRuntime.isReady) {
      _createdLink = widget.demoLink;
      _backendCreated = false;
      return;
    }

    try {
      final draft = SparkDraft(
        category: _categoryFromString(widget.category),
        messageText: widget.message,
        senderName: widget.senderName.trim().isEmpty ? null : widget.senderName.trim(),
        nameDisplayMode: _nameDisplayFromString(widget.nameDisplayMode),
        deliveryMethod: _deliveryFromString(widget.deliveryMethod),
        recipientMasked: widget.safeRecipient,
        recipientHash: _simpleRecipientHash(widget.recipientRaw),
        isDemo: true,
      );
      final record = await SparkBackendService().createDemoSpark(draft);
      _createdLink = 'https://secretspark.app/r/${record.secretCode}';
      _backendCreated = true;
    } catch (error, stackTrace) {
      debugPrint('SecretSpark create spark failed: $error');
      debugPrintStack(stackTrace: stackTrace);
      _createdLink = widget.demoLink;
      _backendCreated = false;
    }
  }

  SparkCategory _categoryFromString(String value) {
    switch (value.toUpperCase()) {
      case 'FAMILY':
        return SparkCategory.family;
      case 'FRIEND':
      case 'FRIENDS':
        return SparkCategory.friend;
      case 'WORK':
        return SparkCategory.work;
      case 'PARTNER':
      default:
        return SparkCategory.partner;
    }
  }

  SparkDeliveryMethod _deliveryFromString(String value) {
    switch (value.toLowerCase()) {
      case 'sms':
        return SparkDeliveryMethod.sms;
      case 'email':
        return SparkDeliveryMethod.email;
      case 'telegram':
        return SparkDeliveryMethod.telegram;
      case 'whatsapp':
      default:
        return SparkDeliveryMethod.whatsapp;
    }
  }

  SparkNameDisplayMode _nameDisplayFromString(String value) {
    switch (value) {
      case 'already_in_message':
        return SparkNameDisplayMode.alreadyInMessage;
      case 'no_name':
        return SparkNameDisplayMode.noName;
      case 'add_at_end':
      default:
        return SparkNameDisplayMode.addAtEnd;
    }
  }

  String _simpleRecipientHash(String value) {
    var hash = 0;
    final normalized = value.trim().toLowerCase();
    for (final unit in normalized.codeUnits) {
      hash = (hash * 31 + unit) & 0x7fffffff;
    }
    return 'demo_$hash';
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050816),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(child: CustomPaint(painter: _PrepareBackgroundPainter(accent: _accent))),
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(22, 18, 22, 28),
                  child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 420),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                child: _done ? _SuccessContent(
                  key: const ValueKey('success'),
                  channelTitle: widget.channelTitle,
                  safeRecipient: widget.safeRecipient,
                  accent: _accent,
                  createdLink: _createdLink ?? widget.demoLink,
                  backendCreated: _backendCreated,
                  onDone: () => Navigator.of(context).popUntil((route) => route.isFirst),
                ) : _PreparingContent(
                  key: const ValueKey('preparing'),
                  fade: _fade,
                  text: _steps[_step],
                  accent: _accent,
                ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PreparingContent extends StatelessWidget {
  const _PreparingContent({super.key, required this.fade, required this.text, required this.accent});

  final Animation<double> fade;
  final String text;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Align(
          alignment: Alignment.centerLeft,
          child: IconButton(
            onPressed: () => Navigator.of(context).pop(),
            icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70),
          ),
        ),
        const Spacer(),
        FadeTransition(
          opacity: Tween<double>(begin: 0.45, end: 1).animate(fade),
          child: Container(
            width: 118,
            height: 118,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(colors: [accent.withOpacity(0.75), accent.withOpacity(0.22), Colors.transparent]),
              boxShadow: [BoxShadow(color: accent.withOpacity(0.35), blurRadius: 46, spreadRadius: 8)],
            ),
            child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 44),
          ),
        ),
        const SizedBox(height: 34),
        AnimatedSwitcher(
          duration: const Duration(milliseconds: 320),
          child: Text(
            text,
            key: ValueKey(text),
            textAlign: TextAlign.center,
            style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.w900, height: 1.15),
          ),
        ),
        const SizedBox(height: 12),
        Text(
          'A private reveal is being prepared. The sender name stays hidden until the end of the moment.',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white.withOpacity(0.50), fontSize: 13, height: 1.45, fontWeight: FontWeight.w600),
        ),
        const Spacer(),
        LinearProgressIndicator(
          minHeight: 5,
          borderRadius: BorderRadius.circular(99),
          backgroundColor: Colors.white.withOpacity(0.08),
          valueColor: AlwaysStoppedAnimation(accent),
        ),
      ],
    );
  }
}

class _SuccessContent extends StatelessWidget {
  const _SuccessContent({
    super.key,
    required this.channelTitle,
    required this.safeRecipient,
    required this.accent,
    required this.createdLink,
    required this.backendCreated,
    required this.onDone,
  });

  final String channelTitle;
  final String safeRecipient;
  final Color accent;
  final String createdLink;
  final bool backendCreated;
  final VoidCallback onDone;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          children: [
            IconButton(
              onPressed: () => Navigator.of(context).pop(),
              icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70),
            ),
            const Spacer(),
            Text('SecretSpark', style: TextStyle(color: Colors.white.withOpacity(0.78), fontWeight: FontWeight.w900)),
            const Spacer(),
            const SizedBox(width: 48),
          ],
        ),
        const Spacer(),
        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.065),
            borderRadius: BorderRadius.circular(32),
            border: Border.all(color: Colors.white.withOpacity(0.12)),
            boxShadow: [BoxShadow(color: accent.withOpacity(0.12), blurRadius: 44, offset: const Offset(0, 18))],
          ),
          child: Column(
            children: [
              Container(
                width: 74,
                height: 74,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: accent.withOpacity(0.14),
                  border: Border.all(color: accent.withOpacity(0.42)),
                ),
                child: Icon(Icons.mark_email_read_rounded, color: accent, size: 34),
              ),
              const SizedBox(height: 22),
              const Text('Your moment is ready ✨', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 27, fontWeight: FontWeight.w900, height: 1.05)),
              const SizedBox(height: 10),
              Text('Demo mode: no real message has been sent yet.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(0.50), fontSize: 13, height: 1.4, fontWeight: FontWeight.w600)),
              const SizedBox(height: 22),
              _InfoRow(label: 'Channel', value: channelTitle),
              const SizedBox(height: 10),
              _InfoRow(label: 'Receiver', value: safeRecipient),
              const SizedBox(height: 10),
              _InfoRow(label: backendCreated ? 'Link' : 'Demo link', value: createdLink),
              const SizedBox(height: 10),
              Text(
                backendCreated
                    ? 'Backend connected: this SecretSpark was saved with a real unique code.'
                    : 'Backend not connected yet: demo link is shown until Supabase keys are configured.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white.withOpacity(0.42), fontSize: 11.5, height: 1.35, fontWeight: FontWeight.w600),
              ),

            ],
          ),
        ),
        const SizedBox(height: 22),
        ElevatedButton.icon(
          onPressed: onDone,
          icon: const Icon(Icons.check_circle_rounded),
          label: const Text('Done'),
          style: ElevatedButton.styleFrom(
            backgroundColor: accent,
            foregroundColor: const Color(0xFF050816),
            elevation: 0,
            minimumSize: const Size(double.infinity, 58),
            textStyle: const TextStyle(fontWeight: FontWeight.w900),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          ),
        ),
        const Spacer(),
      ],
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value});
  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(color: const Color(0xFF0B1020).withOpacity(0.72), borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white.withOpacity(0.08))),
      child: Row(
        children: [
          SizedBox(width: 88, child: Text(label, style: TextStyle(color: Colors.white.withOpacity(0.42), fontSize: 12, fontWeight: FontWeight.w800))),
          Expanded(child: Text(value, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w800))),
        ],
      ),
    );
  }
}

class _PrepareBackgroundPainter extends CustomPainter {
  _PrepareBackgroundPainter({required this.accent});
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFF050816));
    final pink = Paint()
      ..shader = RadialGradient(colors: [accent.withOpacity(0.22), Colors.transparent]).createShader(Rect.fromCircle(center: Offset(size.width * 0.76, size.height * 0.20), radius: size.width * 0.72));
    canvas.drawRect(Offset.zero & size, pink);
    final violet = Paint()
      ..shader = RadialGradient(colors: [accent.withOpacity(0.16), Colors.transparent]).createShader(Rect.fromCircle(center: Offset(size.width * 0.18, size.height * 0.78), radius: size.width * 0.78));
    canvas.drawRect(Offset.zero & size, violet);

    final starPaint = Paint()..color = Colors.white.withOpacity(0.25);
    for (int i = 0; i < 44; i++) {
      final x = (i * 73) % size.width;
      final y = (i * 131) % size.height;
      canvas.drawCircle(Offset(x.toDouble(), y.toDouble()), i % 5 == 0 ? 1.3 : 0.7, starPaint);
    }
  }

  @override
  bool shouldRepaint(covariant _PrepareBackgroundPainter oldDelegate) => oldDelegate.accent != accent;
}
