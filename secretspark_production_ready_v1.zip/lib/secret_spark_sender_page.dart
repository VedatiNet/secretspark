import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'secret_spark_cinematic_page.dart';
import 'delivery_simulation_page.dart';

class SecretSparkSenderPage extends StatefulWidget {
  const SecretSparkSenderPage({super.key});

  @override
  State<SecretSparkSenderPage> createState() => _SecretSparkSenderPageState();
}

class _SecretSparkSenderPageState extends State<SecretSparkSenderPage> {
  final _messageController = TextEditingController();
  final Random _random = Random();

  String _selectedCategory = 'PARTNER';
  bool _experienceApproved = false;

  final List<Map<String, dynamic>> _categories = const [
    {
      'id': 'PARTNER',
      'label': 'Partner',
      'hint': 'Romantic',
      'icon': Icons.favorite_rounded,
      'color': Color(0xFFE879F9),
    },
    {
      'id': 'FAMILY',
      'label': 'Family',
      'hint': 'Heartfelt',
      'icon': Icons.home_rounded,
      'color': Color(0xFFFBBF24),
    },
    {
      'id': 'FRIEND',
      'label': 'Friends',
      'hint': 'Memorable',
      'icon': Icons.diversity_3_rounded,
      'color': Color(0xFF60A5FA),
    },
    {
      'id': 'WORK',
      'label': 'Work',
      'hint': 'Respectful',
      'icon': Icons.business_center_rounded,
      'color': Color(0xFF34D399),
    },
  ];

  final Map<String, List<String>> _magicMessages = const {
    'PARTNER': [
      'Some people enter your life quietly, but somehow become the loudest part of your heart. You are one of those rare moments I never want to forget.',
      'I do not always know how to say it perfectly, but you make ordinary days feel warmer, softer, and more meaningful.',
      'There is something about you that feels like home and magic at the same time. I just wanted you to know that.',
      'Maybe this is just a small message, but behind it is a very real feeling: you matter to me more than you know.',
    ],
    'FAMILY': [
      'Family is not only about being close every day. It is about knowing that somewhere in this world, there are people who make you feel safe. You are that for me.',
      'I may not say it often enough, but I am grateful for you, for your love, your patience, and the quiet strength you give me.',
      'Some people are blessings we get used to too easily. Today I just wanted to remind you that you are one of mine.',
      'Thank you for being part of my life in a way no one else can replace.',
    ],
    'FRIEND': [
      'Some friendships do not need daily conversations to stay real. They simply exist, strong and honest, no matter how much time passes.',
      'Life feels lighter when you have people who understand your silence, your jokes, and your chaos. Thank you for being one of those people.',
      'This is your reminder that you are appreciated more than you probably realize.',
      'A good friend is a rare kind of magic. I am lucky I found that in you.',
    ],
    'WORK': [
      'Your effort, attitude, and consistency do not go unnoticed. Sometimes a simple message is enough to say: respect.',
      'Working with people who bring calm, focus, and good energy makes a real difference. You are one of those people.',
      'Professionalism is not only about results. It is also about character. Thank you for showing both.',
      'This is a small note of appreciation for the value you bring and the way you show up.',
    ],
  };

  @override
  void initState() {
    super.initState();
    _messageController.addListener(() {
      if (_experienceApproved) {
        setState(() => _experienceApproved = false);
      } else {
        setState(() {});
      }
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  void _selectCategory(String categoryId) {
    HapticFeedback.selectionClick();
    setState(() {
      _selectedCategory = categoryId;
      _experienceApproved = false;
    });
  }

  void _magicFill() {
    HapticFeedback.lightImpact();
    final options = _magicMessages[_selectedCategory] ?? _magicMessages['PARTNER']!;
    final current = _messageController.text.trim();
    String next = options[_random.nextInt(options.length)];
    if (options.length > 1) {
      while (next == current) {
        next = options[_random.nextInt(options.length)];
      }
    }
    _messageController.text = next;
    _messageController.selection = TextSelection.fromPosition(TextPosition(offset: next.length));
    setState(() => _experienceApproved = false);
  }

  Future<void> _previewCinematicReveal() async {
    final message = _messageController.text.trim();
    if (message.isEmpty) {
      _showSnack('Write a message first, or use Magic Fill.');
      return;
    }

    final approved = await Navigator.of(context).push<bool>(
      MaterialPageRoute(
        builder: (_) => SecretSparkCinematicPage(
          message: message,
          category: _selectedCategory,
          previewMode: true,
        ),
      ),
    );

    if (!mounted) return;
    if (approved == true) {
      setState(() => _experienceApproved = true);
      _showSnack('Reveal approved. You can continue to delivery.');
    } else {
      setState(() => _experienceApproved = false);
    }
  }

  Future<void> _continueToDelivery() async {
    if (!_experienceApproved) {
      _showSnack('Preview and approve the cinematic reveal first.');
      return;
    }

    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => DeliverySimulationPage(
          message: _messageController.text.trim(),
          category: _selectedCategory,
        ),
      ),
    );
  }

  void _showSnack(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xFF111827),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final selected = _categories.firstWhere((cat) => cat['id'] == _selectedCategory);
    final accent = selected['color'] as Color;
    final message = _messageController.text.trim();
    final previewText = message.isEmpty
        ? 'Your words will appear here as a soft preview before the cinematic reveal.'
        : message;

    return Scaffold(
      backgroundColor: const Color(0xFF050816),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(child: CustomPaint(painter: _SenderBackgroundPainter(accent: accent))),
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(20, 18, 20, 28),
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const _PremiumHeader(),
                  const SizedBox(height: 10),
                  const _PriceNotice(),
                  const SizedBox(height: 22),
                  _SectionLabel(text: 'Choose the feeling'),
                  const SizedBox(height: 12),
                  _CategoryGrid(
                    categories: _categories,
                    selectedCategory: _selectedCategory,
                    onSelected: _selectCategory,
                  ),
                  const SizedBox(height: 22),
                  _SectionLabel(text: 'Live message preview'),
                  const SizedBox(height: 12),
                  _LivePreviewCard(text: previewText, accent: accent, category: selected['label'] as String),
                  const SizedBox(height: 20),
                  _SectionLabel(text: 'Write the message'),
                  const SizedBox(height: 12),
                  _MessageComposer(controller: _messageController, accent: accent),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _magicFill,
                    icon: const Icon(Icons.auto_awesome_rounded),
                    label: const Text('Spark the emotion'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: const Color(0xFFF8FAFC),
                      side: BorderSide(color: accent.withOpacity(0.55)),
                      minimumSize: const Size(double.infinity, 50),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    onPressed: _previewCinematicReveal,
                    icon: const Icon(Icons.play_circle_fill_rounded),
                    label: const Text('Preview the Cinematic Reveal'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: accent,
                      foregroundColor: const Color(0xFF050816),
                      elevation: 0,
                      minimumSize: const Size(double.infinity, 58),
                      textStyle: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.2),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  AnimatedOpacity(
                    opacity: _experienceApproved ? 1.0 : 0.45,
                    duration: const Duration(milliseconds: 220),
                    child: ElevatedButton(
                      onPressed: _continueToDelivery,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _experienceApproved ? const Color(0xFFF8FAFC) : const Color(0xFF334155),
                        foregroundColor: _experienceApproved ? const Color(0xFF050816) : Colors.white70,
                        elevation: 0,
                        minimumSize: const Size(double.infinity, 56),
                        textStyle: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.5),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                      ),
                      child: Text(_experienceApproved ? 'Deliver this moment — \$1.99' : 'Approve reveal to continue'),
                    ),
                  ),
                  const SizedBox(height: 18),
                  const _LegalFooter(),
                ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PremiumHeader extends StatelessWidget {
  const _PremiumHeader();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const Text(
          'SecretSpark',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFFE5E7EB),
            fontSize: 36,
            fontWeight: FontWeight.w900,
            letterSpacing: -0.8,
            shadows: [
              Shadow(color: Color(0x55FFFFFF), blurRadius: 18),
            ],
          ),
        ),
        const SizedBox(height: 7),
        const Text(
          'Turn emotions into unforgettable moments.',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Color(0xFFCBD5E1),
            fontSize: 14,
            height: 1.35,
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }
}


class _PriceNotice extends StatelessWidget {
  const _PriceNotice();

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        decoration: BoxDecoration(
          color: const Color(0xFFFFD700).withOpacity(0.10),
          borderRadius: BorderRadius.circular(99),
          border: Border.all(color: const Color(0xFFFFD700).withOpacity(0.28)),
        ),
        child: const Text(
          '\$1.99 per SecretSpark moment',
          style: TextStyle(
            color: Color(0xFFFFD700),
            fontSize: 12,
            fontWeight: FontWeight.w900,
            letterSpacing: 0.2,
          ),
        ),
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel({required this.text});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text.toUpperCase(),
      style: TextStyle(
        color: Colors.white.withOpacity(0.46),
        fontSize: 10,
        fontWeight: FontWeight.w800,
        letterSpacing: 1.8,
      ),
    );
  }
}

class _CategoryGrid extends StatelessWidget {
  const _CategoryGrid({required this.categories, required this.selectedCategory, required this.onSelected});

  final List<Map<String, dynamic>> categories;
  final String selectedCategory;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: categories.map((cat) {
        final isSelected = selectedCategory == cat['id'];
        final color = cat['color'] as Color;
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: InkWell(
              borderRadius: BorderRadius.circular(22),
              onTap: () => onSelected(cat['id'] as String),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 220),
                padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 7),
                decoration: BoxDecoration(
                  color: isSelected ? color.withOpacity(0.16) : Colors.white.withOpacity(0.045),
                  borderRadius: BorderRadius.circular(22),
                  border: Border.all(color: isSelected ? color.withOpacity(0.85) : Colors.white.withOpacity(0.08)),
                  boxShadow: isSelected ? [BoxShadow(color: color.withOpacity(0.20), blurRadius: 22, spreadRadius: 1)] : [],
                ),
                child: Column(
                  children: [
                    Icon(cat['icon'] as IconData, color: isSelected ? color : Colors.white54, size: 21),
                    const SizedBox(height: 7),
                    Text(cat['label'] as String, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 3),
                    Text(cat['hint'] as String, maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withOpacity(0.38), fontSize: 8, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _LivePreviewCard extends StatelessWidget {
  const _LivePreviewCard({required this.text, required this.accent, required this.category});

  final String text;
  final Color accent;
  final String category;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(22),
      decoration: BoxDecoration(
        color: const Color(0xFF0B1020).withOpacity(0.82),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: accent.withOpacity(0.20)),
        boxShadow: [BoxShadow(color: accent.withOpacity(0.10), blurRadius: 36, spreadRadius: 1)],
      ),
      child: Column(
        children: [
          Icon(Icons.auto_awesome_rounded, color: accent, size: 20),
          const SizedBox(height: 16),
          Text(
            '“$text”',
            textAlign: TextAlign.center,
            maxLines: 6,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              color: Colors.white.withOpacity(0.92),
              fontSize: 16,
              height: 1.55,
              fontStyle: FontStyle.italic,
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 18),
          Text('Prepared for a $category reveal', style: TextStyle(color: Colors.white.withOpacity(0.30), fontSize: 10, letterSpacing: 1.2)),
        ],
      ),
    );
  }
}

class _MessageComposer extends StatelessWidget {
  const _MessageComposer({required this.controller, required this.accent});

  final TextEditingController controller;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.055),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: TextField(
        controller: controller,
        maxLines: 5,
        minLines: 4,
        cursorColor: accent,
        style: const TextStyle(color: Colors.white, fontSize: 15, height: 1.45),
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: 'Write something they will feel, not just read...',
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.28)),
        ),
      ),
    );
  }
}

class _SenderBackgroundPainter extends CustomPainter {
  _SenderBackgroundPainter({required this.accent});
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = RadialGradient(
        colors: [accent.withOpacity(0.20), Colors.transparent],
      ).createShader(Rect.fromCircle(center: Offset(size.width * 0.5, 40), radius: size.width * 0.8));
    canvas.drawRect(Offset.zero & size, paint);

    final goldPaint = Paint()
      ..shader = RadialGradient(
        colors: [const Color(0xFFFBBF24).withOpacity(0.11), Colors.transparent],
      ).createShader(Rect.fromCircle(center: Offset(size.width * 0.15, size.height * 0.55), radius: size.width * 0.6));
    canvas.drawRect(Offset.zero & size, goldPaint);
  }

  @override
  bool shouldRepaint(covariant _SenderBackgroundPainter oldDelegate) => oldDelegate.accent != accent;
}

class _LegalFooter extends StatelessWidget {
  const _LegalFooter();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          'No login. No app download. Private reveal links.',
          textAlign: TextAlign.center,
          style: TextStyle(
            color: Colors.white.withOpacity(0.32),
            fontSize: 11.5,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 6,
          children: [
            _FooterLink(label: 'Terms', route: '/terms'),
            _FooterDot(),
            _FooterLink(label: 'Privacy', route: '/privacy'),
            _FooterDot(),
            _FooterLink(label: 'Contact', route: '/contact'),
          ],
        ),
      ],
    );
  }
}

class _FooterLink extends StatelessWidget {
  const _FooterLink({required this.label, required this.route});
  final String label;
  final String route;

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () => Navigator.of(context).pushNamed(route),
      style: TextButton.styleFrom(
        foregroundColor: Colors.white.withOpacity(0.46),
        visualDensity: VisualDensity.compact,
        padding: const EdgeInsets.symmetric(horizontal: 4),
        textStyle: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800),
      ),
      child: Text(label),
    );
  }
}

class _FooterDot extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Text('•', style: TextStyle(color: Colors.white.withOpacity(0.24))),
    );
  }
}
