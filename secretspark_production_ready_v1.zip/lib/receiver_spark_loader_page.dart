import 'package:flutter/material.dart';

import 'backend/backend_runtime.dart';
import 'backend/spark_backend_service.dart';
import 'secret_spark_cinematic_page.dart';

class ReceiverSparkLoaderPage extends StatefulWidget {
  const ReceiverSparkLoaderPage({super.key, required this.secretCode});

  final String secretCode;

  @override
  State<ReceiverSparkLoaderPage> createState() => _ReceiverSparkLoaderPageState();
}

class _ReceiverSparkLoaderPageState extends State<ReceiverSparkLoaderPage> {
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final ready = await SecretSparkBackendRuntime.initializeIfConfigured();
    if (!mounted) return;

    if (!ready) {
      setState(() {
        _error = 'Backend is not connected yet. Add your Supabase URL and anon key to open real SecretSpark links.';
      });
      return;
    }

    try {
      final service = SparkBackendService();
      final spark = await service.getSparkByCode(widget.secretCode);
      if (!mounted) return;

      if (spark == null) {
        setState(() => _error = 'This SecretSpark link was not found or has expired.');
        return;
      }

      await service.markOpened(sparkId: spark.id);
      if (!mounted) return;

      final senderName = spark.nameDisplayMode == 'add_at_end' ? (spark.senderName ?? '') : '';
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (_) => SecretSparkCinematicPage(
            message: spark.messageText,
            category: spark.category,
            senderName: senderName,
          ),
        ),
      );
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = 'Could not open this SecretSpark yet. Please try again.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050816),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: _error == null ? _Loading(code: widget.secretCode) : _ErrorState(message: _error!),
            ),
          ),
        ),
      ),
    );
  }
}

class _Loading extends StatelessWidget {
  const _Loading({required this.code});
  final String code;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 94,
          height: 94,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: Colors.white.withOpacity(0.18)),
            boxShadow: [BoxShadow(color: Colors.white.withOpacity(0.08), blurRadius: 34)],
          ),
          child: const Center(child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.6)),
        ),
        const SizedBox(height: 28),
        const Text('Opening your SecretSpark…', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 10),
        Text('Code $code', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 12, letterSpacing: 1.4, fontWeight: FontWeight.w700)),
      ],
    );
  }
}

class _ErrorState extends StatelessWidget {
  const _ErrorState({required this.message});
  final String message;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.lock_outline_rounded, color: Colors.white.withOpacity(0.78), size: 56),
        const SizedBox(height: 22),
        const Text('SecretSpark link unavailable', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        Text(message, textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(0.55), fontSize: 13.5, height: 1.45, fontWeight: FontWeight.w600)),
        const SizedBox(height: 24),
        OutlinedButton.icon(
          onPressed: () => Navigator.of(context).pushReplacementNamed('/'),
          icon: const Icon(Icons.arrow_back_rounded),
          label: const Text('Back to SecretSpark'),
          style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: BorderSide(color: Colors.white.withOpacity(0.18))),
        ),
      ],
    );
  }
}
