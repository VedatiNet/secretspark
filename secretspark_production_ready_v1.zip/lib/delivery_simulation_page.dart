import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'secret_spark_cinematic_page.dart';
import 'payment_page.dart';

enum DeliveryChannel { whatsapp, sms, email, telegram }

enum NameDisplayMode { addAtEnd, alreadyInsideMessage, noSeparateName }

class DeliverySimulationPage extends StatefulWidget {
  const DeliverySimulationPage({
    super.key,
    required this.message,
    required this.category,
  });

  final String message;
  final String category;

  @override
  State<DeliverySimulationPage> createState() => _DeliverySimulationPageState();
}

class _DeliverySimulationPageState extends State<DeliverySimulationPage> {
  DeliveryChannel _selected = DeliveryChannel.whatsapp;
  final String _demoLink = 'https://secretspark.app/r/AX82KD';
  final TextEditingController _recipientController = TextEditingController(text: '+1 555 013 7288');
  final TextEditingController _senderNameController = TextEditingController();
  NameDisplayMode _nameDisplayMode = NameDisplayMode.addAtEnd;

  @override
  void dispose() {
    _recipientController.dispose();
    _senderNameController.dispose();
    super.dispose();
  }

  ChannelInfo get _info {
    switch (_selected) {
      case DeliveryChannel.whatsapp:
        return const ChannelInfo(
          title: 'WhatsApp Business',
          shortTitle: 'WhatsApp',
          badge: 'Most trusted',
          senderName: 'SecretSpark Business',
          icon: Icons.chat_rounded,
          accent: Color(0xFF25D366),
          helper: 'Best when the receiver uses WhatsApp every day.',
          recipientLabel: 'Receiver WhatsApp number',
          recipientHint: '+1 555 013 7288',
          keyboardType: TextInputType.phone,
        );
      case DeliveryChannel.sms:
        return const ChannelInfo(
          title: 'SMS',
          shortTitle: 'SMS',
          badge: 'Most mysterious',
          senderName: 'SecretSpark',
          icon: Icons.sms_rounded,
          accent: Color(0xFF60A5FA),
          helper: 'Best for a direct private surprise.',
          recipientLabel: 'Receiver phone number',
          recipientHint: '+1 555 013 7288',
          keyboardType: TextInputType.phone,
        );
      case DeliveryChannel.email:
        return const ChannelInfo(
          title: 'Email',
          shortTitle: 'Email',
          badge: 'Most elegant',
          senderName: 'SecretSpark',
          icon: Icons.mail_rounded,
          accent: Color(0xFFFBBF24),
          helper: 'Best when the receiver checks email calmly.',
          recipientLabel: 'Receiver email address',
          recipientHint: 'name@email.com',
          keyboardType: TextInputType.emailAddress,
        );
      case DeliveryChannel.telegram:
        return const ChannelInfo(
          title: 'Telegram',
          shortTitle: 'Telegram',
          badge: 'Most private',
          senderName: 'SecretSpark Bot',
          icon: Icons.send_rounded,
          accent: Color(0xFF38BDF8),
          helper: 'Best for receivers who actively use Telegram.',
          recipientLabel: 'Receiver Telegram username',
          recipientHint: '@username',
          keyboardType: TextInputType.text,
        );
    }
  }

  String get _finalSenderName {
    if (_nameDisplayMode != NameDisplayMode.addAtEnd) return '';
    return _senderNameController.text.trim();
  }

  String get _safeRecipient {
    final raw = _recipientController.text.trim();
    if (raw.isEmpty) return 'not set yet';
    if (_selected == DeliveryChannel.email) {
      final parts = raw.split('@');
      if (parts.length == 2 && parts.first.length > 2) {
        return '${parts.first.substring(0, 2)}•••@${parts.last}';
      }
      return raw;
    }
    if (_selected == DeliveryChannel.telegram) return raw.startsWith('@') ? raw : '@$raw';
    final digits = raw.replaceAll(RegExp(r'[^0-9]'), '');
    if (digits.length <= 4) return raw;
    return '•••• ${digits.substring(digits.length - 4)}';
  }

  String get _channelText {
    switch (_selected) {
      case DeliveryChannel.whatsapp:
        return 'Someone created a SecretSpark moment for you ✨\n\nNo login. No app download. No personal data required.\n\nOpen when you have a quiet moment:\n$_demoLink';
      case DeliveryChannel.sms:
        return 'SecretSpark ✨ Someone created a moment for you. No login, no app download, no personal data required. Open: $_demoLink';
      case DeliveryChannel.email:
        return 'Someone created a SecretSpark moment for you ✨';
      case DeliveryChannel.telegram:
        return '✨ A SecretSpark moment was created for you.\n\nNo login. No download. No personal data required.\n\nTap to open the reveal:\n$_demoLink';
    }
  }

  void _changeChannel(DeliveryChannel value) {
    HapticFeedback.selectionClick();
    setState(() {
      _selected = value;
      switch (value) {
        case DeliveryChannel.whatsapp:
        case DeliveryChannel.sms:
          _recipientController.text = '+1 555 013 7288';
          break;
        case DeliveryChannel.email:
          _recipientController.text = 'receiver@email.com';
          break;
        case DeliveryChannel.telegram:
          _recipientController.text = '@receiver';
          break;
      }
    });
  }

  Future<void> _continueToPayment() async {
    HapticFeedback.lightImpact();
    await Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PaymentPage(
          message: widget.message,
          category: widget.category,
          senderName: _finalSenderName,
          channelTitle: _info.title,
          safeRecipient: _safeRecipient,
          demoLink: _demoLink,
        ),
      ),
    );
  }

  void _copyDemo() {
    Clipboard.setData(ClipboardData(text: _channelText));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Channel preview text copied.'), behavior: SnackBarBehavior.floating),
    );
  }

  @override
  Widget build(BuildContext context) {
    final info = _info;

    return Scaffold(
      backgroundColor: const Color(0xFF050816),
      body: SafeArea(
        child: Stack(
          children: [
            Positioned.fill(child: CustomPaint(painter: _DeliveryBackgroundPainter(accent: info.accent))),
            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 430),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.fromLTRB(18, 14, 18, 28),
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _TopBar(accent: info.accent),
                  const SizedBox(height: 16),
                  Text(
                    'Deliver the moment ✨',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white.withOpacity(0.94), fontSize: 26, fontWeight: FontWeight.w900, height: 1.05),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Choose the channel and see exactly how it may feel to the receiver.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white.withOpacity(0.48), fontSize: 12.5, fontWeight: FontWeight.w600, height: 1.35),
                  ),
                  const SizedBox(height: 22),
                  _NameDisplayOptions(
                    selected: _nameDisplayMode,
                    controller: _senderNameController,
                    accent: info.accent,
                    onModeChanged: (mode) => setState(() => _nameDisplayMode = mode),
                    onNameChanged: (_) => setState(() {}),
                  ),
                  const SizedBox(height: 14),
                  _ChannelSelector(selected: _selected, onChanged: _changeChannel),
                  const SizedBox(height: 16),
                  _RecipientInput(info: info, controller: _recipientController, onChanged: (_) => setState(() {})),
                  const SizedBox(height: 16),
                  _RecipientCard(info: info, safeRecipient: _safeRecipient),
                  const SizedBox(height: 16),
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 260),
                    switchInCurve: Curves.easeOutCubic,
                    switchOutCurve: Curves.easeInCubic,
                    child: _RealisticPreview(
                      key: ValueKey(_selected),
                      channel: _selected,
                      info: info,
                      text: _channelText,
                      link: _demoLink,
                    ),
                  ),
                  const SizedBox(height: 18),
                  _SafetyCard(accent: info.accent),
                  const SizedBox(height: 22),
                  ElevatedButton.icon(
                    onPressed: _continueToPayment,
                    icon: const Icon(Icons.auto_awesome_rounded),
                    label: const Text('Continue to Payment — \$1.99'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: info.accent,
                      foregroundColor: const Color(0xFF050816),
                      elevation: 0,
                      minimumSize: const Size(double.infinity, 58),
                      textStyle: const TextStyle(fontWeight: FontWeight.w900, letterSpacing: 0.2),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  OutlinedButton.icon(
                    onPressed: _copyDemo,
                    icon: const Icon(Icons.copy_rounded),
                    label: const Text('Copy this channel preview text'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: Colors.white70,
                      side: BorderSide(color: Colors.white.withOpacity(0.14)),
                      minimumSize: const Size(double.infinity, 52),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Demo mode: no real WhatsApp, SMS, email, or Telegram message is sent yet.',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white.withOpacity(0.32), fontSize: 11, height: 1.4),
                  ),
                ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ChannelInfo {
  const ChannelInfo({
    required this.title,
    required this.shortTitle,
    required this.badge,
    required this.senderName,
    required this.icon,
    required this.accent,
    required this.helper,
    required this.recipientLabel,
    required this.recipientHint,
    required this.keyboardType,
  });

  final String title;
  final String shortTitle;
  final String badge;
  final String senderName;
  final IconData icon;
  final Color accent;
  final String helper;
  final String recipientLabel;
  final String recipientHint;
  final TextInputType keyboardType;
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.accent});
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        IconButton(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white70),
        ),
        Expanded(
          child: Text(
            'SecretSpark',
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.white.withOpacity(0.9), fontSize: 18, fontWeight: FontWeight.w900, letterSpacing: 0.3),
          ),
        ),
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(shape: BoxShape.circle, color: accent.withOpacity(0.12), border: Border.all(color: accent.withOpacity(0.22))),
          child: Icon(Icons.auto_awesome_rounded, color: accent, size: 18),
        ),
      ],
    );
  }
}

class _NameDisplayOptions extends StatelessWidget {
  const _NameDisplayOptions({
    required this.selected,
    required this.controller,
    required this.accent,
    required this.onModeChanged,
    required this.onNameChanged,
  });

  final NameDisplayMode selected;
  final TextEditingController controller;
  final Color accent;
  final ValueChanged<NameDisplayMode> onModeChanged;
  final ValueChanged<String> onNameChanged;

  @override
  Widget build(BuildContext context) {
    final empty = controller.text.trim().isEmpty;
    final showNameField = selected == NameDisplayMode.addAtEnd;

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.055),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: showNameField && empty ? const Color(0xFFFBBF24).withOpacity(0.30) : accent.withOpacity(0.22)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'How should your name appear at the end?',
            style: TextStyle(color: accent.withOpacity(0.92), fontSize: 13.5, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 10),
          _NameModeTile(
            title: 'Add my name at the end',
            subtitle: 'Best when your message does not already include your name.',
            value: NameDisplayMode.addAtEnd,
            selected: selected,
            accent: accent,
            onChanged: onModeChanged,
          ),
          if (showNameField) ...[
            const SizedBox(height: 8),
            TextField(
              controller: controller,
              onChanged: onNameChanged,
              textCapitalization: TextCapitalization.words,
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.black.withOpacity(0.18),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: Colors.white.withOpacity(0.10))),
                enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: Colors.white.withOpacity(0.10))),
                focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(18), borderSide: BorderSide(color: accent.withOpacity(0.55))),
                labelText: 'The name they know you by',
                labelStyle: TextStyle(color: Colors.white.withOpacity(0.62), fontWeight: FontWeight.w700),
                hintText: 'Example: Vedat',
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.26)),
                suffixIcon: empty ? Icon(Icons.info_outline_rounded, color: const Color(0xFFFBBF24).withOpacity(0.9), size: 20) : Icon(Icons.check_circle_rounded, color: accent, size: 21),
              ),
            ),
            if (empty) ...[
              const SizedBox(height: 8),
              Text(
                'If your name is already inside the message, choose the second option to avoid repeating it.',
                style: TextStyle(color: const Color(0xFFFBBF24).withOpacity(0.78), fontSize: 11.5, height: 1.3, fontWeight: FontWeight.w700),
              ),
            ],
          ],
          const SizedBox(height: 8),
          _NameModeTile(
            title: 'My name is already inside the message',
            subtitle: 'No separate “From …” line will be added.',
            value: NameDisplayMode.alreadyInsideMessage,
            selected: selected,
            accent: accent,
            onChanged: onModeChanged,
          ),
          const SizedBox(height: 8),
          _NameModeTile(
            title: 'Continue without adding a name',
            subtitle: 'Use only if the message itself makes it clear enough.',
            value: NameDisplayMode.noSeparateName,
            selected: selected,
            accent: accent,
            onChanged: onModeChanged,
          ),
          const SizedBox(height: 10),
          Text(
            'The sender name is never shown in the delivery preview. It appears only at the end of the reveal when you choose the first option.',
            style: TextStyle(color: Colors.white.withOpacity(0.42), fontSize: 11.5, height: 1.35, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}

class _NameModeTile extends StatelessWidget {
  const _NameModeTile({
    required this.title,
    required this.subtitle,
    required this.value,
    required this.selected,
    required this.accent,
    required this.onChanged,
  });

  final String title;
  final String subtitle;
  final NameDisplayMode value;
  final NameDisplayMode selected;
  final Color accent;
  final ValueChanged<NameDisplayMode> onChanged;

  @override
  Widget build(BuildContext context) {
    final isSelected = value == selected;
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () {
        HapticFeedback.selectionClick();
        onChanged(value);
      },
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected ? accent.withOpacity(0.13) : Colors.white.withOpacity(0.035),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: isSelected ? accent.withOpacity(0.48) : Colors.white.withOpacity(0.08)),
        ),
        child: Row(
          children: [
            Icon(isSelected ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded, color: isSelected ? accent : Colors.white38, size: 20),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 13.2)),
                  const SizedBox(height: 3),
                  Text(subtitle, style: TextStyle(color: Colors.white.withOpacity(0.45), fontSize: 11.2, height: 1.25, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ChannelSelector extends StatelessWidget {
  const _ChannelSelector({required this.selected, required this.onChanged});

  final DeliveryChannel selected;
  final ValueChanged<DeliveryChannel> onChanged;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          children: [
            Expanded(child: _ChannelChip(channel: DeliveryChannel.whatsapp, label: 'WhatsApp', emoji: '💬', selected: selected, onChanged: onChanged)),
            const SizedBox(width: 10),
            Expanded(child: _ChannelChip(channel: DeliveryChannel.sms, label: 'SMS', emoji: '✨', selected: selected, onChanged: onChanged)),
          ],
        ),
        const SizedBox(height: 10),
        Row(
          children: [
            Expanded(child: _ChannelChip(channel: DeliveryChannel.email, label: 'Email', emoji: '✉️', selected: selected, onChanged: onChanged)),
            const SizedBox(width: 10),
            Expanded(child: _ChannelChip(channel: DeliveryChannel.telegram, label: 'Telegram', emoji: '🔒', selected: selected, onChanged: onChanged)),
          ],
        ),
      ],
    );
  }
}

class _ChannelChip extends StatelessWidget {
  const _ChannelChip({required this.channel, required this.label, required this.emoji, required this.selected, required this.onChanged});

  final DeliveryChannel channel;
  final String label;
  final String emoji;
  final DeliveryChannel selected;
  final ValueChanged<DeliveryChannel> onChanged;

  @override
  Widget build(BuildContext context) {
    final active = selected == channel;
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => onChanged(channel),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
        decoration: BoxDecoration(
          color: active ? Colors.white.withOpacity(0.14) : Colors.white.withOpacity(0.055),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: active ? Colors.white.withOpacity(0.36) : Colors.white.withOpacity(0.08)),
          boxShadow: active ? [BoxShadow(color: Colors.white.withOpacity(0.06), blurRadius: 22, offset: const Offset(0, 10))] : null,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(emoji, style: const TextStyle(fontSize: 17)),
            const SizedBox(width: 8),
            Flexible(child: Text(label, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 12))),
          ],
        ),
      ),
    );
  }
}

class _RecipientInput extends StatelessWidget {
  const _RecipientInput({required this.info, required this.controller, required this.onChanged});

  final ChannelInfo info;
  final TextEditingController controller;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.055),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: info.accent.withOpacity(0.22)),
      ),
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        keyboardType: info.keyboardType,
        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        decoration: InputDecoration(
          border: InputBorder.none,
          labelText: info.recipientLabel,
          labelStyle: TextStyle(color: info.accent.withOpacity(0.82), fontWeight: FontWeight.w800),
          hintText: info.recipientHint,
          hintStyle: TextStyle(color: Colors.white.withOpacity(0.26)),
        ),
      ),
    );
  }
}

class _RecipientCard extends StatelessWidget {
  const _RecipientCard({required this.info, required this.safeRecipient});

  final ChannelInfo info;
  final String safeRecipient;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: const Color(0xFF0B1020).withOpacity(0.86),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: info.accent.withOpacity(0.22)),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(color: info.accent.withOpacity(0.16), shape: BoxShape.circle),
            child: Icon(info.icon, color: info.accent),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Flexible(child: Text(info.title, style: const TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w900))),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(color: info.accent.withOpacity(0.14), borderRadius: BorderRadius.circular(99)),
                      child: Text(info.badge, style: TextStyle(color: info.accent, fontSize: 9, fontWeight: FontWeight.w900)),
                    ),
                  ],
                ),
                const SizedBox(height: 5),
                Text('To: $safeRecipient', style: TextStyle(color: Colors.white.withOpacity(0.54), fontSize: 12, fontWeight: FontWeight.w600)),
                const SizedBox(height: 5),
                Text(info.helper, style: TextStyle(color: Colors.white.withOpacity(0.36), fontSize: 11, height: 1.35)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _RealisticPreview extends StatelessWidget {
  const _RealisticPreview({
    super.key,
    required this.channel,
    required this.info,
    required this.text,
    required this.link,
  });

  final DeliveryChannel channel;
  final ChannelInfo info;
  final String text;
  final String link;
  @override
  Widget build(BuildContext context) {
    Widget child;
    switch (channel) {
      case DeliveryChannel.whatsapp:
        child = _WhatsAppPreview(info: info, text: text);
        break;
      case DeliveryChannel.sms:
        child = _SmsPreview(info: info, text: text);
        break;
      case DeliveryChannel.email:
        child = _EmailPreview(info: info, link: link);
        break;
      case DeliveryChannel.telegram:
        child = _TelegramPreview(info: info, text: text);
        break;
    }

    return _PhoneFrame(accent: info.accent, child: child);
  }
}

class _PhoneFrame extends StatelessWidget {
  const _PhoneFrame({required this.child, required this.accent});
  final Widget child;
  final Color accent;

  @override
  Widget build(BuildContext context) {
    // IMPORTANT:
    // This widget is inside SingleChildScrollView. A child inside a scroll view
    // gets unbounded height. The WhatsApp/SMS/Telegram mockups use Expanded(),
    // so the phone preview MUST have a fixed/bounded height. Otherwise Flutter
    // throws RenderBox/Box.dart assertion errors and the screen becomes black.
    final screenHeight = MediaQuery.of(context).size.height;
    final frameHeight = screenHeight < 720 ? 400.0 : 460.0;

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFF020617),
        borderRadius: BorderRadius.circular(36),
        border: Border.all(color: Colors.white.withOpacity(0.12)),
        boxShadow: [BoxShadow(color: accent.withOpacity(0.10), blurRadius: 32, offset: const Offset(0, 16))],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(28),
        child: SizedBox(
          height: frameHeight,
          width: double.infinity,
          child: ColoredBox(
            color: const Color(0xFF0F172A),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _WhatsAppPreview extends StatelessWidget {
  const _WhatsAppPreview({required this.info, required this.text});
  final ChannelInfo info;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(colors: [Color(0xFF0B141A), Color(0xFF101A20)], begin: Alignment.topCenter, end: Alignment.bottomCenter),
      ),
      child: Column(
        children: [
          _StatusBar(color: Colors.white.withOpacity(0.78)),
          Container(
            height: 58,
            color: const Color(0xFF1F2C34),
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                const Icon(Icons.arrow_back_rounded, color: Colors.white70, size: 22),
                const SizedBox(width: 8),
                CircleAvatar(
                  radius: 18,
                  backgroundColor: info.accent.withOpacity(0.16),
                  child: Icon(Icons.auto_awesome_rounded, color: info.accent, size: 18),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(children: const [
                        Flexible(child: Text('SecretSpark Business', overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 14))),
                        SizedBox(width: 4),
                        Icon(Icons.verified_rounded, color: Color(0xFF53BDEB), size: 15),
                      ]),
                      Text('business account', style: TextStyle(color: Colors.white.withOpacity(0.50), fontSize: 11, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                const Icon(Icons.more_vert_rounded, color: Colors.white70, size: 22),
              ],
            ),
          ),
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(child: CustomPaint(painter: _WhatsAppPatternPainter())),
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    margin: const EdgeInsets.only(top: 14),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(color: const Color(0xFF182229), borderRadius: BorderRadius.circular(12)),
                    child: Text('Today', style: TextStyle(color: Colors.white.withOpacity(0.48), fontSize: 10, fontWeight: FontWeight.w800)),
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Container(
                    margin: const EdgeInsets.only(top: 58, right: 12, left: 62),
                    padding: const EdgeInsets.fromLTRB(14, 12, 12, 8),
                    decoration: const BoxDecoration(
                      color: Color(0xFF005C4B),
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(16), topRight: Radius.circular(4), bottomLeft: Radius.circular(16), bottomRight: Radius.circular(16)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(text, style: const TextStyle(color: Colors.white, fontSize: 13.2, height: 1.42, fontWeight: FontWeight.w500)),
                        const SizedBox(height: 6),
                        Row(mainAxisSize: MainAxisSize.min, children: [
                          Text('09:41', style: TextStyle(color: Colors.white.withOpacity(0.62), fontSize: 10)),
                          const SizedBox(width: 3),
                          const Icon(Icons.done_all_rounded, color: Color(0xFF53BDEB), size: 15),
                        ]),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 56,
            color: const Color(0xFF0B141A),
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
            child: Row(
              children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    decoration: BoxDecoration(color: const Color(0xFF1F2C34), borderRadius: BorderRadius.circular(22)),
                    child: Row(children: [
                      Icon(Icons.emoji_emotions_outlined, color: Colors.white.withOpacity(0.48), size: 20),
                      const SizedBox(width: 8),
                      Text('Message', style: TextStyle(color: Colors.white.withOpacity(0.36), fontSize: 13)),
                    ]),
                  ),
                ),
                const SizedBox(width: 8),
                CircleAvatar(radius: 20, backgroundColor: info.accent, child: const Icon(Icons.mic_rounded, color: Colors.white, size: 20)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _SmsPreview extends StatelessWidget {
  const _SmsPreview({required this.info, required this.text});
  final ChannelInfo info;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF050505),
      child: Column(
        children: [
          _StatusBar(color: Colors.white.withOpacity(0.92)),
          Container(
            padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
            decoration: BoxDecoration(color: const Color(0xFF111113), border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.08)))),
            child: Row(
              children: [
                const Icon(Icons.chevron_left_rounded, color: Color(0xFF0A84FF), size: 28),
                Expanded(
                  child: Column(
                    children: [
                      CircleAvatar(radius: 18, backgroundColor: Colors.white.withOpacity(0.12), child: const Icon(Icons.auto_awesome_rounded, color: Colors.white70, size: 18)),
                      const SizedBox(height: 4),
                      const Text('SecretSpark', style: TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
                const SizedBox(width: 28),
              ],
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 18, 12, 10),
              child: Column(
                children: [
                  Text('iMessage • Today 9:41 AM', style: TextStyle(color: Colors.white.withOpacity(0.32), fontSize: 10.5, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 16),
                  Align(
                    alignment: Alignment.centerLeft,
                    child: Container(
                      constraints: const BoxConstraints(maxWidth: 285),
                      padding: const EdgeInsets.fromLTRB(14, 11, 14, 12),
                      decoration: const BoxDecoration(
                        color: Color(0xFF2C2C2E),
                        borderRadius: BorderRadius.only(topLeft: Radius.circular(20), topRight: Radius.circular(20), bottomRight: Radius.circular(20), bottomLeft: Radius.circular(6)),
                      ),
                      child: Text(text, style: const TextStyle(color: Colors.white, fontSize: 14, height: 1.34, fontWeight: FontWeight.w500)),
                    ),
                  ),
                  const Spacer(),
                  Row(
                    children: [
                      Expanded(
                        child: Container(
                          height: 40,
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                          decoration: BoxDecoration(border: Border.all(color: Colors.white.withOpacity(0.16)), borderRadius: BorderRadius.circular(22)),
                          alignment: Alignment.centerLeft,
                          child: Text('Text Message', style: TextStyle(color: Colors.white.withOpacity(0.36), fontSize: 13)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      CircleAvatar(radius: 19, backgroundColor: const Color(0xFF3A3A3C), child: Icon(Icons.arrow_upward_rounded, color: Colors.white.withOpacity(0.50), size: 19)),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EmailPreview extends StatelessWidget {
  const _EmailPreview({required this.info, required this.link});
  final ChannelInfo info;
  final String link;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFFF8FAFC),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _StatusBar(color: const Color(0xFF0F172A)),
          Container(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
            decoration: const BoxDecoration(color: Colors.white),
            child: Row(
              children: [
                const Icon(Icons.arrow_back_rounded, color: Color(0xFF334155)),
                const SizedBox(width: 14),
                const Expanded(child: Text('Gmail', style: TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.w900, fontSize: 18))),
                Icon(Icons.more_vert_rounded, color: Colors.black.withOpacity(0.58)),
              ],
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 22),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Someone created a moment for you ✨', style: TextStyle(color: Color(0xFF0F172A), fontSize: 21, fontWeight: FontWeight.w900, height: 1.15)),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      CircleAvatar(radius: 20, backgroundColor: info.accent.withOpacity(0.20), child: Icon(Icons.auto_awesome_rounded, color: info.accent, size: 20)),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          const Text('SecretSpark', style: TextStyle(color: Color(0xFF0F172A), fontWeight: FontWeight.w900, fontSize: 13.5)),
                          Text('reveal@secretspark.app • to me', style: TextStyle(color: Colors.black.withOpacity(0.46), fontSize: 11.5, fontWeight: FontWeight.w600)),
                        ]),
                      ),
                      Text('9:41 AM', style: TextStyle(color: Colors.black.withOpacity(0.42), fontSize: 11.5)),
                    ],
                  ),
                  const SizedBox(height: 18),
                  Container(
                    padding: const EdgeInsets.all(18),
                    decoration: BoxDecoration(
                      color: const Color(0xFF0B1020),
                      borderRadius: BorderRadius.circular(22),
                      boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.12), blurRadius: 24, offset: const Offset(0, 14))],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Row(children: [
                          Container(width: 34, height: 34, decoration: BoxDecoration(color: info.accent.withOpacity(0.16), shape: BoxShape.circle), child: Icon(Icons.auto_awesome_rounded, color: info.accent, size: 18)),
                          const SizedBox(width: 10),
                          const Expanded(child: Text('SecretSpark', style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w900))),
                        ]),
                        const SizedBox(height: 18),
                        Text('A cinematic moment was created for you.', style: TextStyle(color: Colors.white.withOpacity(0.94), fontSize: 20, fontWeight: FontWeight.w900, height: 1.15)),
                        const SizedBox(height: 10),
                        Text('No login, no app download, and no personal data required. The sender name appears only after the reveal is opened.', style: TextStyle(color: Colors.white.withOpacity(0.62), fontSize: 13, height: 1.45, fontWeight: FontWeight.w600)),
                        const SizedBox(height: 18),
                        Container(
                          height: 48,
                          decoration: BoxDecoration(color: info.accent, borderRadius: BorderRadius.circular(16)),
                          alignment: Alignment.center,
                          child: const Text('Open your SecretSpark moment', style: TextStyle(color: Color(0xFF0B1020), fontWeight: FontWeight.w900, fontSize: 13)),
                        ),
                        const SizedBox(height: 12),
                        Text(link, textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withOpacity(0.34), fontSize: 10.5)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text('This email is a private delivery preview. The real system will include verified domain authentication.', style: TextStyle(color: Colors.black.withOpacity(0.42), fontSize: 11, height: 1.4, fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TelegramPreview extends StatelessWidget {
  const _TelegramPreview({required this.info, required this.text});
  final ChannelInfo info;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      color: const Color(0xFF17212B),
      child: Column(
        children: [
          _StatusBar(color: Colors.white.withOpacity(0.86)),
          Container(
            height: 58,
            color: const Color(0xFF212D3B),
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Row(
              children: [
                const Icon(Icons.arrow_back_rounded, color: Colors.white70, size: 22),
                const SizedBox(width: 8),
                CircleAvatar(radius: 18, backgroundColor: info.accent, child: const Icon(Icons.auto_awesome_rounded, color: Colors.white, size: 18)),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('SecretSpark Bot', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 14)),
                      Text('bot • secure preview', style: TextStyle(color: Colors.white.withOpacity(0.44), fontSize: 11, fontWeight: FontWeight.w600)),
                    ],
                  ),
                ),
                const Icon(Icons.more_vert_rounded, color: Colors.white70, size: 22),
              ],
            ),
          ),
          Expanded(
            child: Stack(
              children: [
                Positioned.fill(child: CustomPaint(painter: _TelegramPatternPainter())),
                Align(
                  alignment: Alignment.topCenter,
                  child: Container(
                    margin: const EdgeInsets.only(top: 14),
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(color: const Color(0xFF0F172A).withOpacity(0.62), borderRadius: BorderRadius.circular(12)),
                    child: Text('Today', style: TextStyle(color: Colors.white.withOpacity(0.50), fontSize: 10, fontWeight: FontWeight.w800)),
                  ),
                ),
                Align(
                  alignment: Alignment.topLeft,
                  child: Container(
                    margin: const EdgeInsets.only(top: 56, left: 12, right: 50),
                    padding: const EdgeInsets.fromLTRB(13, 11, 13, 8),
                    decoration: const BoxDecoration(
                      color: Color(0xFF2B5278),
                      borderRadius: BorderRadius.only(topLeft: Radius.circular(6), topRight: Radius.circular(18), bottomLeft: Radius.circular(18), bottomRight: Radius.circular(18)),
                    ),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(text, style: const TextStyle(color: Colors.white, fontSize: 13.5, height: 1.38, fontWeight: FontWeight.w500)),
                      const SizedBox(height: 10),
                      Container(
                        padding: const EdgeInsets.all(10),
                        decoration: BoxDecoration(color: Colors.white.withOpacity(0.08), borderRadius: BorderRadius.circular(12), border: Border(left: BorderSide(color: info.accent, width: 3))),
                        child: Row(children: [
                          Icon(Icons.link_rounded, color: info.accent, size: 18),
                          const SizedBox(width: 8),
                          const Expanded(child: Text('Open your SecretSpark moment', style: TextStyle(color: Colors.white, fontSize: 12.5, fontWeight: FontWeight.w800))),
                        ]),
                      ),
                      const SizedBox(height: 5),
                      Align(alignment: Alignment.centerRight, child: Text('09:41', style: TextStyle(color: Colors.white.withOpacity(0.56), fontSize: 10))),
                    ]),
                  ),
                ),
              ],
            ),
          ),
          Container(
            height: 55,
            color: const Color(0xFF17212B),
            padding: const EdgeInsets.fromLTRB(10, 8, 10, 8),
            child: Row(children: [
              Icon(Icons.attach_file_rounded, color: Colors.white.withOpacity(0.42), size: 21),
              const SizedBox(width: 8),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(color: const Color(0xFF212D3B), borderRadius: BorderRadius.circular(22)),
                  alignment: Alignment.centerLeft,
                  child: Text('Message', style: TextStyle(color: Colors.white.withOpacity(0.36), fontSize: 13)),
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.mic_rounded, color: Colors.white.withOpacity(0.42), size: 21),
            ]),
          ),
        ],
      ),
    );
  }
}

class _StatusBar extends StatelessWidget {
  const _StatusBar({required this.color});
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 28,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Text('9:41', style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w800)),
          const Spacer(),
          Icon(Icons.signal_cellular_alt_rounded, color: color, size: 14),
          const SizedBox(width: 4),
          Icon(Icons.wifi_rounded, color: color, size: 14),
          const SizedBox(width: 4),
          Icon(Icons.battery_full_rounded, color: color, size: 16),
        ],
      ),
    );
  }
}

class _SafetyCard extends StatelessWidget {
  const _SafetyCard({required this.accent});
  final Color accent;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.045),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withOpacity(0.08)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.verified_user_rounded, color: accent, size: 20),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Receiver trust text stays clear: no login, no download, and no personal data requested. The sender name is recommended so the moment does not feel like spam.',
              style: TextStyle(color: Colors.white.withOpacity(0.54), fontSize: 12, height: 1.45, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
    );
  }
}

class _DeliveryBackgroundPainter extends CustomPainter {
  _DeliveryBackgroundPainter({required this.accent});
  final Color accent;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = RadialGradient(colors: [accent.withOpacity(0.18), Colors.transparent]).createShader(
        Rect.fromCircle(center: Offset(size.width * 0.82, size.height * 0.10), radius: size.width * 0.8),
      );
    canvas.drawRect(Offset.zero & size, paint);

    final gold = Paint()
      ..shader = RadialGradient(colors: [const Color(0xFFFBBF24).withOpacity(0.09), Colors.transparent]).createShader(
        Rect.fromCircle(center: Offset(size.width * 0.14, size.height * 0.70), radius: size.width * 0.72),
      );
    canvas.drawRect(Offset.zero & size, gold);
  }

  @override
  bool shouldRepaint(covariant _DeliveryBackgroundPainter oldDelegate) => oldDelegate.accent != accent;
}

class _WhatsAppPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.018)..strokeWidth = 1;
    for (double x = -30; x < size.width; x += 56) {
      for (double y = -20; y < size.height; y += 56) {
        canvas.drawCircle(Offset(x + 18, y + 18), 7, paint..style = PaintingStyle.stroke);
        canvas.drawLine(Offset(x + 32, y + 40), Offset(x + 44, y + 48), paint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _TelegramPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.white.withOpacity(0.018)..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 62) {
      for (double y = 0; y < size.height; y += 62) {
        final path = Path()
          ..moveTo(x + 12, y + 22)
          ..lineTo(x + 40, y + 10)
          ..lineTo(x + 31, y + 42)
          ..close();
        canvas.drawPath(path, paint..style = PaintingStyle.stroke);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
